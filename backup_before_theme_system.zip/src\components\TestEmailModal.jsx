import React, { useState } from 'react';
import { X, Send, Sparkles, CheckCircle2 } from 'lucide-react';
import { sendTestEmail } from '../utils/api';

export default function TestEmailModal({ 
  currentEmail, 
  isOpen, 
  onClose,
  onSuccess 
}) {
  const [preset, setPreset] = useState('google');
  const [senderName, setSenderName] = useState('Google Security');
  const [senderEmail, setSenderEmail] = useState('no-reply@accounts.google.com');
  const [subject, setSubject] = useState('⚡ Kode Verifikasi Keamanan Google Anda: 894021');
  const [withAttachment, setWithAttachment] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [success, setSuccess] = useState(false);

  if (!isOpen) return null;

  const handlePresetSelect = (type) => {
    setPreset(type);
    if (type === 'google') {
      setSenderName('Google Verification Team');
      setSenderEmail('no-reply@accounts.google.com');
      setSubject('⚡ Kode Verifikasi Akun Google Anda: ' + Math.floor(100000 + Math.random() * 900000));
    } else if (type === 'tiktok') {
      setSenderName('TikTok Security');
      setSenderEmail('register@tiktok.com');
      setSubject('⚡ [TikTok] Verifikasi Pendaftaran Akun Baru');
    } else if (type === 'invoice') {
      setSenderName('Billing & Payments');
      setSenderEmail('billing@flatimo.me');
      setSubject('⚡ Konfirmasi Transaksi Pembayaran Berhasil #INV-' + Math.floor(1000 + Math.random() * 9000));
      setWithAttachment(true);
    }
  };

  const handleSend = async (e) => {
    e.preventDefault();
    setIsSending(true);
    try {
      await sendTestEmail({
        to: currentEmail,
        senderName,
        senderEmail,
        subject,
        withAttachment
      });

      setSuccess(true);
      if (onSuccess) onSuccess();
      setTimeout(() => {
        setSuccess(false);
        onClose();
      }, 1500);
    } catch (err) {
      alert('Gagal mengirim email simulasi: ' + err.message);
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-dark-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg rounded-3xl bg-dark-900 border border-brand-yellow/40 shadow-glow-yellow p-6 sm:p-8">
        
        {/* Close */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-white bg-dark-950 border border-slate-800"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Title */}
        <div className="flex items-center gap-2 mb-2 text-brand-yellow">
          <Sparkles className="w-5 h-5 fill-brand-yellow" />
          <h3 className="font-black text-lg text-white">Simulasi Tes Email Masuk</h3>
        </div>
        <p className="text-xs text-slate-400 mb-6">
          Uji coba kecepatan penerimaan email secara instan ke inbox <strong className="text-brand-yellow font-mono">{currentEmail}</strong>.
        </p>

        {/* Presets */}
        <div className="mb-4">
          <label className="block text-xs font-bold text-slate-300 mb-2">Pilih Template Email:</label>
          <div className="grid grid-cols-3 gap-2">
            <button
              type="button"
              onClick={() => handlePresetSelect('google')}
              className={`p-2.5 rounded-xl text-xs font-bold transition-all border ${
                preset === 'google'
                  ? 'bg-brand-yellow/15 text-brand-yellow border-brand-yellow shadow-glow-yellow-sm'
                  : 'bg-dark-950 text-slate-400 border-slate-800 hover:text-white'
              }`}
            >
              Google OTP
            </button>

            <button
              type="button"
              onClick={() => handlePresetSelect('tiktok')}
              className={`p-2.5 rounded-xl text-xs font-bold transition-all border ${
                preset === 'tiktok'
                  ? 'bg-brand-yellow/15 text-brand-yellow border-brand-yellow shadow-glow-yellow-sm'
                  : 'bg-dark-950 text-slate-400 border-slate-800 hover:text-white'
              }`}
            >
              TikTok
            </button>

            <button
              type="button"
              onClick={() => handlePresetSelect('invoice')}
              className={`p-2.5 rounded-xl text-xs font-bold transition-all border ${
                preset === 'invoice'
                  ? 'bg-brand-yellow/15 text-brand-yellow border-brand-yellow shadow-glow-yellow-sm'
                  : 'bg-dark-950 text-slate-400 border-slate-800 hover:text-white'
              }`}
            >
              Invoice + File
            </button>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSend} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Nama Pengirim:</label>
            <input
              type="text"
              value={senderName}
              onChange={(e) => setSenderName(e.target.value)}
              className="w-full bg-dark-950 border border-slate-800 focus:border-brand-yellow px-3.5 py-2 rounded-xl text-xs font-semibold text-white focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Email Pengirim:</label>
            <input
              type="text"
              value={senderEmail}
              onChange={(e) => setSenderEmail(e.target.value)}
              className="w-full bg-dark-950 border border-slate-800 focus:border-brand-yellow px-3.5 py-2 rounded-xl text-xs font-mono text-white focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Subjek Pesan:</label>
            <input
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full bg-dark-950 border border-slate-800 focus:border-brand-yellow px-3.5 py-2 rounded-xl text-xs font-semibold text-white focus:outline-none"
            />
          </div>

          <div className="flex items-center gap-2 pt-1">
            <input
              type="checkbox"
              id="attachmentCheck"
              checked={withAttachment}
              onChange={(e) => setWithAttachment(e.target.checked)}
              className="w-4 h-4 rounded border-slate-700 text-brand-yellow focus:ring-brand-yellow cursor-pointer"
            />
            <label htmlFor="attachmentCheck" className="text-xs text-slate-300 cursor-pointer font-medium">
              Sertakan contoh lampiran file (.txt report)
            </label>
          </div>

          <button
            type="submit"
            disabled={isSending || success}
            className="w-full flex items-center justify-center gap-2 py-3 rounded-2xl font-bold text-sm text-dark-950 glow-btn-yellow mt-4"
          >
            {success ? (
              <>
                <CheckCircle2 className="w-5 h-5 text-dark-950" />
                <span>Pesan Berhasil Terkirim!</span>
              </>
            ) : isSending ? (
              <span>Mengirim Email...</span>
            ) : (
              <>
                <Send className="w-4 h-4" />
                <span>⚡ Tembak Email Sekarang</span>
              </>
            )}
          </button>
        </form>

      </div>
    </div>
  );
}
