import express from 'express';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { config } from './config.js';
import apiRouter from './routes/api.js';
import streamRouter from './routes/stream.js';
import webhookRouter from './routes/webhook.js';
import { startSmtpServer } from './smtp.js';
import { startAutoCleaner } from './utils/cleaner.js';
import { startTelegramBot } from './telegramBot.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();

// Global Middlewares
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Webhook-Secret', 'X-Forwarded-To', 'X-API-Key', 'api-key']
}));

// Standard JSON parser (for regular API requests)
app.use(express.json({ limit: '20mb' }));
app.use(express.urlencoded({ extended: true, limit: '20mb' }));

// Request Logger
app.use((req, res, next) => {
  if (!req.path.includes('/stream')) {
    console.log(`[HTTP] ${req.method} ${req.path}`);
  }
  next();
});

// Universal API Routes (/api/v1 and legacy /api compatibility for all bots)
app.use('/api/v1', apiRouter);
app.use('/api/v1', streamRouter);
app.use('/api/v1/webhook', webhookRouter);

app.use('/api', apiRouter);
app.use('/api', streamRouter);
app.use('/api/webhook', webhookRouter);

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'Flatimo Mail Engine',
    time: new Date().toISOString(),
    uptime: Math.floor(process.uptime())
  });
});

// Static frontend serving (for Production build)
const clientDistPath = path.join(__dirname, '..', 'dist');
if (fs.existsSync(clientDistPath)) {
  app.use(express.static(clientDistPath));
  app.get('*', (req, res) => {
    if (!req.path.startsWith('/api')) {
      res.sendFile(path.join(clientDistPath, 'index.html'));
    }
  });
}

// Start HTTP Server
const server = app.listen(config.port, '0.0.0.0', () => {
  console.log(`
  ⚡ =================================================== ⚡
       FLATIMO MAIL - HIGH PERFORMANCE TEMP MAIL ENGINE   
  ⚡ =================================================== ⚡
  🌐 Web UI & REST API : http://localhost:${config.port}
  📫 SMTP Mail Server   : Port ${config.smtpPort} (MX Priority 1)
  🚀 Environment        : ${config.env}
  📁 Active Domains     : ${config.defaultDomains.join(', ')}
  🕒 Retention Period   : ${config.retentionHours} Hours
  🤖 Telegram Bot       : Live Synced Active
  =======================================================
  `);
});

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`\n❌ [Error] Port ${config.port} sedang digunakan oleh proses lain.`);
    console.error(`💡 Solusi: Anda dapat mengubah PORT di file .env atau mematikan proses node lama terlebih dahulu.\n`);
  } else {
    console.error('[HTTP Server Error]:', err.message);
  }
  process.exit(1);
});

// Start Background Services
try {
  startSmtpServer();
} catch (err) {
  console.error('[SMTP Engine Error]: Could not bind SMTP port:', err.message);
}

startAutoCleaner();

// Start Live Telegram Bot
try {
  startTelegramBot();
} catch (err) {
  console.error('[Telegram Bot Error]:', err.message);
}

// Handle graceful shutdown
process.on('SIGTERM', () => {
  console.log('[System] Gracefully shutting down...');
  server.close(() => {
    process.exit(0);
  });
});
