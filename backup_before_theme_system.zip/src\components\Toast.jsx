import React from 'react';
import { Zap, X } from 'lucide-react';

export default function Toast({ toasts = [], onDismiss }) {
  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-2.5 max-w-sm w-full pointer-events-none">
      {toasts.map((t) => (
        <div
          key={t.id}
          className={`pointer-events-auto flex items-start gap-3 p-4 rounded-2xl border backdrop-blur-xl shadow-2xl transition-all animate-in slide-in-from-bottom-5 duration-300 ${
            t.type === 'mail'
              ? 'bg-dark-900/95 border-brand-yellow/50 shadow-glow-yellow'
              : 'bg-dark-900/95 border-brand-orange/50 shadow-glow-orange'
          }`}
        >
          <div className="p-2 rounded-xl bg-brand-yellow/15 text-brand-yellow shrink-0">
            <Zap className="w-5 h-5 fill-brand-yellow" />
          </div>

          <div className="flex-1 min-w-0">
            <div className="font-bold text-xs text-brand-yellow mb-0.5">
              {t.title || '⚡ Email Baru Masuk!'}
            </div>
            <div className="text-xs text-white font-semibold truncate">
              {t.message}
            </div>
            {t.subtitle && (
              <div className="text-[11px] text-slate-400 truncate mt-0.5">
                {t.subtitle}
              </div>
            )}
          </div>

          <button
            onClick={() => onDismiss(t.id)}
            className="p-1 rounded-lg text-slate-500 hover:text-slate-200"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      ))}
    </div>
  );
}
