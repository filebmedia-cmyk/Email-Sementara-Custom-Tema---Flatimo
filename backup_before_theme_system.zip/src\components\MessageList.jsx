import React from 'react';
import { Mail, Paperclip, Clock, Trash2, ArrowRight, Sparkles, Inbox as InboxIcon } from 'lucide-react';

export default function MessageList({
  messages = [],
  onSelectMessage,
  onDeleteMessage,
  onOpenTestModal,
  selectedMessageId = null
}) {
  const formatTime = (dateStr) => {
    try {
      const date = new Date(dateStr);
      const now = new Date();
      const diffMs = now - date;
      const diffSec = Math.floor(diffMs / 1000);
      const diffMin = Math.floor(diffSec / 60);
      const diffHr = Math.floor(diffMin / 60);

      if (diffSec < 60) return 'Baru saja';
      if (diffMin < 60) return `${diffMin} mnt lalu`;
      if (diffHr < 24) return `${diffHr} jam lalu`;

      return date.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }) + ', ' +
             date.toLocaleDateString('id-ID', { day: 'numeric', month: 'short' });
    } catch {
      return dateStr;
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto mt-4 sm:mt-6 px-1 sm:px-0">
      <div className="rounded-2xl sm:rounded-3xl bg-dark-900/85 border border-slate-800/80 overflow-hidden shadow-2xl backdrop-blur-xl">
        
        {/* Header */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-3.5 sm:py-4 border-b border-slate-800/80 bg-dark-950/40">
          <div className="flex items-center gap-2 sm:gap-2.5">
            <div className="p-1.5 rounded-lg bg-brand-yellow/10 text-brand-yellow">
              <InboxIcon className="w-4 h-4" />
            </div>
            <h2 className="font-bold text-white text-sm sm:text-base">Kotak Masuk</h2>
            <span className="text-[11px] sm:text-xs font-semibold px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">
              {messages.length} pesan
            </span>
          </div>

          <div className="text-[11px] sm:text-xs text-slate-500 hidden sm:block">
            Pesan otomatis terhapus setelah 24 jam
          </div>
        </div>

        {/* Content Area: Empty State or Message List */}
        {messages.length === 0 ? (
          <div className="py-12 sm:py-20 px-4 sm:px-6 text-center flex flex-col items-center justify-center">
            
            {/* Animated Radar Pulse Container */}
            <div className="relative flex items-center justify-center w-24 h-24 sm:w-28 sm:h-28 mb-4 sm:mb-6">
              <div className="absolute inset-0 rounded-full bg-brand-yellow/10 animate-radar-scan pointer-events-none" />
              <div className="absolute inset-2 rounded-full bg-brand-orange/15 animate-ping opacity-25 pointer-events-none" />
              <div className="relative flex items-center justify-center w-14 h-14 sm:w-16 sm:h-16 rounded-xl sm:rounded-2xl bg-dark-950 border border-brand-yellow/40 shadow-glow-yellow-sm text-brand-yellow">
                <Mail className="w-7 h-7 sm:w-8 sm:h-8 stroke-[1.5]" />
              </div>
            </div>

            <h3 className="text-base sm:text-lg font-bold text-white mb-1.5 sm:mb-2">
              Belum Ada Email Masuk
            </h3>
            <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto mb-5 sm:mb-6 leading-relaxed">
              Email baru akan muncul secara instan di sini berkat koneksi <strong className="text-brand-yellow">Priority 1 Real-time</strong>.
            </p>

            <button
              onClick={onOpenTestModal}
              className="flex items-center gap-2 px-4 sm:px-5 py-2.5 sm:py-3 rounded-xl font-bold text-xs sm:text-sm text-dark-950 glow-btn-yellow active:scale-95 transition-all"
            >
              <Sparkles className="w-4 h-4 fill-dark-950" />
              <span>Kirim Email Percobaan Sekarang</span>
            </button>
          </div>
        ) : (
          <div className="divide-y divide-slate-800/60">
            {messages.map((msg) => {
              const isSelected = selectedMessageId === msg.id;
              const senderDisplay = msg.from.name || msg.from.address || msg.from.text || 'Pengirim';
              const initial = senderDisplay.charAt(0).toUpperCase();

              return (
                <div
                  key={msg.id}
                  onClick={() => onSelectMessage(msg.id)}
                  className={`group relative flex items-start gap-3 sm:gap-4 p-3.5 sm:p-5 cursor-pointer transition-all duration-200 active:bg-dark-800/80 ${
                    isSelected
                      ? 'bg-brand-yellow/10 border-l-4 border-l-brand-yellow'
                      : 'hover:bg-dark-850/70'
                  } ${!msg.read ? 'bg-brand-yellow/[0.03]' : ''}`}
                >
                  {/* Sender Avatar */}
                  <div className="relative shrink-0 mt-0.5">
                    <div className="flex items-center justify-center w-8 h-8 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl bg-gradient-to-br from-dark-800 to-dark-950 border border-slate-700 font-bold text-sm sm:text-base text-brand-yellow shadow-sm">
                      {initial}
                    </div>
                    {!msg.read && (
                      <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-brand-orange border-2 border-dark-900 shadow-glow-orange-sm animate-pulse" />
                    )}
                  </div>

                  {/* Message Content Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1.5 mb-1">
                      <div className="flex items-center gap-1.5 truncate">
                        <span className={`text-xs sm:text-sm truncate ${!msg.read ? 'font-bold text-white' : 'font-medium text-slate-300'}`}>
                          {senderDisplay}
                        </span>
                        <span className="text-[11px] text-slate-500 font-mono hidden md:inline truncate max-w-[200px]">
                          &lt;{msg.from.address || msg.from.text}&gt;
                        </span>
                      </div>

                      <div className="flex items-center gap-2 sm:gap-3 shrink-0">
                        {msg.hasAttachments && (
                          <span 
                            title={`${msg.attachmentCount} lampiran file`}
                            className="flex items-center gap-1 text-[10px] sm:text-[11px] font-semibold text-brand-yellow bg-brand-yellow/10 px-1.5 sm:px-2 py-0.5 rounded-md border border-brand-yellow/20"
                          >
                            <Paperclip className="w-3 h-3" />
                            <span>{msg.attachmentCount}</span>
                          </span>
                        )}

                        <span className="flex items-center gap-1 text-[10px] sm:text-xs text-slate-500">
                          <Clock className="w-3 h-3" />
                          {formatTime(msg.date)}
                        </span>

                        {/* Delete single button */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onDeleteMessage(msg.id);
                          }}
                          title="Hapus pesan ini"
                          className="sm:opacity-0 group-hover:opacity-100 p-1 sm:p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition-all"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <h4 className={`text-xs sm:text-sm mb-1 truncate ${!msg.read ? 'font-bold text-brand-yellow' : 'font-medium text-slate-200'}`}>
                      {msg.subject || '(Tanpa Subjek)'}
                    </h4>

                    <p className="text-[11px] sm:text-xs text-slate-400 line-clamp-1">
                      {msg.snippet || 'Klik untuk membuka isi pesan...'}
                    </p>
                  </div>

                  {/* Arrow Indicator */}
                  <div className="hidden sm:flex items-center self-center text-slate-600 group-hover:text-brand-yellow group-hover:translate-x-1 transition-all">
                    <ArrowRight className="w-4 h-4" />
                  </div>
                </div>
              );
            })}
          </div>
        )}

      </div>
    </div>
  );
}
