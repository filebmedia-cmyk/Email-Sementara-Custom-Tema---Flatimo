import React, { useState } from 'react';
import { 
  Shield, 
  Copy, 
  Check, 
  QrCode, 
  Share2, 
  Sparkles, 
  Trash2, 
  RefreshCw, 
  ChevronDown,
  Edit2
} from 'lucide-react';

export default function InboxGenerator({
  currentEmail,
  currentUsername,
  currentDomain,
  domains = [],
  onGenerateRandom,
  onChangeCustom,
  onDeleteInbox,
  onRefreshMessages,
  onOpenQrModal,
  totalEmails = 0,
  unreadEmails = 0,
  isRefreshing = false,
  onCopySuccess
}) {
  const [copied, setCopied] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [customUser, setCustomUser] = useState(currentUsername);

  const handleCopy = () => {
    if (!currentEmail) return;
    navigator.clipboard.writeText(currentEmail);
    setCopied(true);
    if (onCopySuccess) onCopySuccess(currentEmail);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCustomSubmit = (e) => {
    e.preventDefault();
    if (customUser.trim() && customUser.trim() !== currentUsername) {
      onChangeCustom(customUser.trim(), currentDomain);
      setIsEditing(false);
    }
  };

  const handleDomainChange = (newDomain) => {
    onChangeCustom(currentUsername, newDomain);
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: 'Flatimo Mail Inbox',
        text: `Kirim email sementara ke: ${currentEmail}`,
        url: window.location.href,
      }).catch(() => {});
    } else {
      handleCopy();
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-1 sm:px-0">
      {/* Main Responsive Glassmorphic Card */}
      <div className="relative rounded-2xl sm:rounded-3xl p-4 sm:p-7 md:p-8 bg-dark-900/95 border border-brand-yellow/30 shadow-glow-yellow-sm hover:shadow-glow-yellow transition-all duration-300 backdrop-blur-2xl">
        
        {/* Ambient Top Glow Effect */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3/4 h-8 bg-gradient-to-r from-brand-yellow/20 via-brand-orange/30 to-brand-yellow/20 blur-xl pointer-events-none" />

        {/* --- MAIN GENERATOR CONTAINER --- */}
        <div className="flex flex-col xl:flex-row items-stretch xl:items-center gap-3 sm:gap-4">
          
          {/* Email Address Bar (Mobile Stack / Desktop Inline) */}
          <div className="flex-1 flex flex-col sm:flex-row items-stretch sm:items-center gap-2 p-2 sm:p-2.5 rounded-xl sm:rounded-2xl bg-dark-950/90 border border-slate-800 focus-within:border-brand-yellow/60 focus-within:shadow-glow-yellow-sm transition-all">
            
            {/* Top Row on Mobile: Shield + Username Input */}
            <div className="flex items-center gap-2 flex-1 min-w-0 px-1 py-0.5">
              {/* Shield Icon */}
              <div className="flex items-center justify-center w-9 h-9 sm:w-11 sm:h-11 rounded-lg sm:rounded-xl bg-gradient-to-br from-brand-yellow/20 to-brand-orange/20 border border-brand-yellow/40 text-brand-yellow shrink-0">
                <Shield className="w-4 h-4 sm:w-5 sm:h-5 fill-brand-yellow/20" />
              </div>

              {/* Username Input / Custom Edit */}
              <div className="flex-1 min-w-[100px]">
                {isEditing ? (
                  <form onSubmit={handleCustomSubmit} className="flex items-center">
                    <input
                      type="text"
                      value={customUser}
                      onChange={(e) => setCustomUser(e.target.value)}
                      onBlur={handleCustomSubmit}
                      autoFocus
                      placeholder="nama-inbox"
                      className="w-full bg-transparent text-white font-mono font-bold text-sm sm:text-base md:text-lg focus:outline-none border-b border-brand-yellow/60 pb-0.5"
                    />
                  </form>
                ) : (
                  <div 
                    onClick={() => {
                      setCustomUser(currentUsername);
                      setIsEditing(true);
                    }}
                    className="cursor-pointer group flex items-center gap-1.5 py-1"
                    title="Klik untuk mengubah username custom"
                  >
                    <span className="font-mono font-bold text-sm sm:text-base md:text-lg text-white group-hover:text-brand-yellow transition-colors truncate max-w-[160px] sm:max-w-[200px]">
                      {currentUsername || 'nama_inbox'}
                    </span>
                    <Edit2 className="w-3 h-3 text-slate-500 group-hover:text-brand-yellow shrink-0" />
                  </div>
                )}
              </div>
            </div>

            {/* Middle on Mobile / Inline on Desktop: @ Separator + Domain Selector */}
            <div className="flex items-center gap-2 shrink-0 border-t sm:border-t-0 sm:border-l border-slate-800/80 pt-2 sm:pt-0 sm:pl-2">
              <span className="text-brand-yellow font-bold text-base select-none pl-1">@</span>

              {/* Domain Dropdown */}
              <div className="relative flex-1 sm:flex-none min-w-[130px] sm:min-w-[150px]">
                <select
                  value={currentDomain}
                  onChange={(e) => handleDomainChange(e.target.value)}
                  className="appearance-none w-full bg-dark-900 border border-slate-700 hover:border-brand-yellow/50 text-brand-yellow font-semibold text-xs sm:text-sm py-2 pl-3 pr-7 rounded-lg sm:rounded-xl focus:outline-none focus:border-brand-yellow cursor-pointer transition-all"
                >
                  {domains.map((dom) => (
                    <option key={dom} value={dom} className="bg-dark-900 text-white font-sans">
                      {dom}
                    </option>
                  ))}
                </select>
                <ChevronDown className="w-3.5 h-3.5 text-brand-yellow absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>

              {/* Quick Action Buttons (Copy, QR, Share) */}
              <div className="flex items-center gap-1 shrink-0 pl-1">
                {/* Copy Button */}
                <button
                  onClick={handleCopy}
                  title="Salin alamat email"
                  className={`p-2 sm:p-2.5 rounded-lg sm:rounded-xl transition-all ${
                    copied 
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' 
                      : 'text-slate-300 hover:text-brand-yellow hover:bg-dark-900 bg-dark-900/60 border border-slate-800'
                  }`}
                >
                  {copied ? <Check className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 sm:w-4 sm:h-4" />}
                </button>

                {/* QR Modal */}
                <button
                  onClick={onOpenQrModal}
                  title="Tampilkan QR Code"
                  className="p-2 sm:p-2.5 rounded-lg sm:rounded-xl text-slate-300 hover:text-brand-yellow hover:bg-dark-900 bg-dark-900/60 border border-slate-800 transition-all"
                >
                  <QrCode className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                </button>

                {/* Share */}
                <button
                  onClick={handleShare}
                  title="Bagikan inbox"
                  className="p-2 sm:p-2.5 rounded-lg sm:rounded-xl text-slate-300 hover:text-brand-yellow hover:bg-dark-900 bg-dark-900/60 border border-slate-800 transition-all"
                >
                  <Share2 className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                </button>
              </div>
            </div>

          </div>

          {/* Action Buttons: New Inbox & Delete */}
          <div className="flex items-center gap-2 sm:gap-2.5 shrink-0">
            {/* Generate / New Inbox Button */}
            <button
              onClick={onGenerateRandom}
              className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 sm:px-6 py-3 sm:py-3.5 rounded-xl sm:rounded-2xl font-bold text-xs sm:text-sm text-dark-950 glow-btn-yellow active:scale-95 transition-transform"
            >
              <Sparkles className="w-4 h-4 fill-dark-950" />
              <span>+ Buat Inbox</span>
            </button>

            {/* Delete Inbox Button */}
            <button
              onClick={onDeleteInbox}
              title="Bersihkan inbox saat ini"
              className="flex items-center justify-center gap-1.5 px-3 sm:px-4 py-3 sm:py-3.5 rounded-xl sm:rounded-2xl font-bold text-xs sm:text-sm text-rose-400 bg-rose-500/10 border border-rose-500/30 hover:bg-rose-500/20 active:scale-95 transition-all"
            >
              <Trash2 className="w-4 h-4" />
              <span className="hidden sm:inline">Hapus</span>
            </button>
          </div>

        </div>

        {/* --- BOTTOM STATUS BAR (Mobile & Desktop Responsive) --- */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-2.5 pt-4 sm:pt-5 mt-4 sm:mt-5 border-t border-slate-800/80 text-[11px] sm:text-xs font-medium text-slate-400">
          
          {/* Counters & Pulse Indicator */}
          <div className="flex items-center justify-between sm:justify-start w-full sm:w-auto gap-3 sm:gap-4">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-brand-yellow shadow-glow-yellow-sm animate-pulse" />
              <span className="text-slate-200 font-semibold">{totalEmails} email</span>
            </div>

            <div className="flex items-center gap-1.5">
              <span className="text-slate-500">•</span>
              <span className={unreadEmails > 0 ? 'text-brand-orange font-bold' : 'text-slate-400'}>
                {unreadEmails} belum dibaca
              </span>
            </div>

            <div className="flex items-center gap-1.5 pl-2 border-l border-slate-800 text-emerald-400">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
              <span className="truncate max-w-[120px] sm:max-w-none">Live SSE (Priority 1)</span>
            </div>
          </div>

          {/* Refresh Action */}
          <div className="flex items-center justify-end w-full sm:w-auto">
            <button
              onClick={onRefreshMessages}
              disabled={isRefreshing}
              className="w-full sm:w-auto flex items-center justify-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-dark-950 border border-slate-800 hover:border-brand-yellow/40 text-slate-300 hover:text-brand-yellow active:scale-95 transition-all"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-brand-yellow' : ''}`} />
              <span>Segarkan Kotak Masuk</span>
            </button>
          </div>

        </div>

      </div>
    </div>
  );
}
