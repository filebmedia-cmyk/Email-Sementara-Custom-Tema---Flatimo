import fs from 'fs';
import path from 'path';
import { config } from './config.js';

// Pastikan direktori data ada
if (!fs.existsSync(config.dataDir)) {
  fs.mkdirSync(config.dataDir, { recursive: true });
}

const dbFilePath = path.join(config.dataDir, 'flatimo_mail.json');

// In-Memory Database Store dengan Auto-Persist ke Disk
class DatabaseStore {
  constructor() {
    this.domains = new Set(config.defaultDomains);
    this.inboxes = new Map(); // email -> { email, createdAt, lastActivity }
    this.messages = new Map(); // id -> messageObj
    this.inboxIndex = new Map(); // email -> Set of messageIds
    this.stats = {
      totalReceived: 0,
      totalAttachments: 0,
      startedAt: new Date().toISOString()
    };
    this.load();
  }

  load() {
    try {
      if (fs.existsSync(dbFilePath)) {
        const raw = fs.readFileSync(dbFilePath, 'utf8');
        const data = JSON.parse(raw);
        if (data.domains && Array.isArray(data.domains)) {
          data.domains.forEach(d => this.domains.add(d.toLowerCase()));
        }
        if (data.inboxes && Array.isArray(data.inboxes)) {
          data.inboxes.forEach(inbox => {
            this.inboxes.set(inbox.email.toLowerCase(), inbox);
          });
        }
        if (data.messages && Array.isArray(data.messages)) {
          data.messages.forEach(msg => {
            this.messages.set(msg.id, msg);
            const email = msg.inboxEmail.toLowerCase();
            if (!this.inboxIndex.has(email)) {
              this.inboxIndex.set(email, new Set());
            }
            this.inboxIndex.get(email).add(msg.id);
          });
        }
        if (data.stats) {
          this.stats = { ...this.stats, ...data.stats };
        }
        console.log(`[DB] Database loaded: ${this.messages.size} messages, ${this.inboxes.size} inboxes, ${this.domains.size} domains.`);
      } else {
        this.save();
      }
    } catch (err) {
      console.error('[DB] Error loading database, initializing clean state:', err.message);
      this.save();
    }
  }

  save() {
    try {
      const data = {
        domains: Array.from(this.domains),
        inboxes: Array.from(this.inboxes.values()),
        messages: Array.from(this.messages.values()),
        stats: this.stats,
        lastSaved: new Date().toISOString()
      };
      fs.writeFileSync(dbFilePath, JSON.stringify(data, null, 2), 'utf8');
    } catch (err) {
      console.error('[DB] Error persisting database:', err.message);
    }
  }

  // Domain Management
  getDomains() {
    return Array.from(this.domains);
  }

  addDomain(domain) {
    const clean = domain.trim().toLowerCase();
    if (!clean) return false;
    this.domains.add(clean);
    this.save();
    return true;
  }

  removeDomain(domain) {
    const clean = domain.trim().toLowerCase();
    const removed = this.domains.delete(clean);
    if (removed) this.save();
    return removed;
  }

  isDomainAllowed(domain) {
    const clean = domain.trim().toLowerCase();
    return this.domains.has(clean);
  }

  // Inbox Management
  getOrCreateInbox(email) {
    const normalized = email.trim().toLowerCase();
    if (!this.inboxes.has(normalized)) {
      const inbox = {
        email: normalized,
        createdAt: new Date().toISOString(),
        lastActivity: new Date().toISOString()
      };
      this.inboxes.set(normalized, inbox);
      if (!this.inboxIndex.has(normalized)) {
        this.inboxIndex.set(normalized, new Set());
      }
      this.save();
      return inbox;
    }
    const existing = this.inboxes.get(normalized);
    existing.lastActivity = new Date().toISOString();
    return existing;
  }

  deleteInbox(email) {
    const normalized = email.trim().toLowerCase();
    const messageIds = this.inboxIndex.get(normalized);
    if (messageIds) {
      for (const id of messageIds) {
        this.messages.delete(id);
      }
      this.inboxIndex.delete(normalized);
    }
    const existed = this.inboxes.delete(normalized);
    this.save();
    return existed;
  }

  // Message Operations
  saveMessage(msg) {
    const normalizedInbox = msg.inboxEmail.trim().toLowerCase();
    this.getOrCreateInbox(normalizedInbox);

    const fullMessage = {
      id: msg.id,
      inboxEmail: normalizedInbox,
      from: msg.from || { text: 'Unknown Sender', address: 'unknown@example.com' },
      to: msg.to || [{ text: normalizedInbox, address: normalizedInbox }],
      subject: msg.subject || '(Tanpa Subjek)',
      text: msg.text || '',
      html: msg.html || '',
      textAsHtml: msg.textAsHtml || '',
      date: msg.date || new Date().toISOString(),
      headers: msg.headers || {},
      attachments: msg.attachments || [],
      size: msg.size || 0,
      read: false,
      createdAt: new Date().toISOString()
    };

    this.messages.set(fullMessage.id, fullMessage);
    if (!this.inboxIndex.has(normalizedInbox)) {
      this.inboxIndex.set(normalizedInbox, new Set());
    }
    this.inboxIndex.get(normalizedInbox).add(fullMessage.id);

    this.stats.totalReceived += 1;
    if (fullMessage.attachments.length > 0) {
      this.stats.totalAttachments += fullMessage.attachments.length;
    }

    this.save();
    return fullMessage;
  }

  getMessages(email) {
    const normalized = email.trim().toLowerCase();
    const messageIds = this.inboxIndex.get(normalized);
    if (!messageIds || messageIds.size === 0) {
      return [];
    }

    const list = [];
    for (const id of messageIds) {
      const msg = this.messages.get(id);
      if (msg) {
        // Return summary for message list (exclude large HTML / body to optimize payload)
        list.push({
          id: msg.id,
          inboxEmail: msg.inboxEmail,
          from: msg.from,
          subject: msg.subject,
          snippet: (msg.text || '').substring(0, 150).trim(),
          date: msg.date,
          read: msg.read,
          hasAttachments: msg.attachments && msg.attachments.length > 0,
          attachmentCount: (msg.attachments || []).length,
          size: msg.size,
          createdAt: msg.createdAt
        });
      }
    }

    // Sort descending (newest first)
    return list.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }

  getMessageById(id) {
    const msg = this.messages.get(id);
    if (msg) {
      msg.read = true; // mark read on open
      this.save();
    }
    return msg || null;
  }

  deleteMessage(id) {
    const msg = this.messages.get(id);
    if (!msg) return false;

    const email = msg.inboxEmail.toLowerCase();
    if (this.inboxIndex.has(email)) {
      this.inboxIndex.get(email).delete(id);
    }
    this.messages.delete(id);
    this.save();
    return true;
  }

  // Auto Retention Cleanup
  cleanupExpired(hours = 24) {
    const now = Date.now();
    const maxAgeMs = hours * 60 * 60 * 1000;
    let deletedCount = 0;

    for (const [id, msg] of this.messages.entries()) {
      const msgTime = new Date(msg.createdAt || msg.date).getTime();
      if (now - msgTime > maxAgeMs) {
        const email = msg.inboxEmail.toLowerCase();
        if (this.inboxIndex.has(email)) {
          this.inboxIndex.get(email).delete(id);
        }
        this.messages.delete(id);
        deletedCount++;
      }
    }

    if (deletedCount > 0) {
      console.log(`[Cleaner] Purged ${deletedCount} expired messages older than ${hours} hours.`);
      this.save();
    }
    return deletedCount;
  }

  getStats() {
    return {
      activeInboxes: this.inboxes.size,
      storedMessages: this.messages.size,
      totalReceived: this.stats.totalReceived,
      totalAttachments: this.stats.totalAttachments,
      activeDomains: this.domains.size,
      uptimeSeconds: Math.floor(process.uptime())
    };
  }
}

export const db = new DatabaseStore();
