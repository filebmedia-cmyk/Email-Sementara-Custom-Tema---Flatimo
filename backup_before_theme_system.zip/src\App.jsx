import React, { useState, useEffect, useRef, useCallback } from 'react';
import Header from './components/Header';
import InboxGenerator from './components/InboxGenerator';
import MessageList from './components/MessageList';
import MessageViewer from './components/MessageViewer';
import ApiDocs from './components/ApiDocs';
import DnsGuide from './components/DnsGuide';
import DomainManager from './components/DomainManager';
import QrModal from './components/QrModal';
import TestEmailModal from './components/TestEmailModal';
import Toast from './components/Toast';
import PixelBackground from './components/PixelBackground';

import { 
  fetchDomains, 
  addDomain as apiAddDomain, 
  deleteDomain as apiDeleteDomain, 
  generateInbox, 
  createCustomInbox, 
  fetchMessages, 
  fetchMessageDetail, 
  deleteMessage as apiDeleteMessage, 
  deleteInbox as apiDeleteInbox,
  fetchStats
} from './utils/api';

import { playMailSound } from './utils/sound';

// Helper to extract email from URL path, query params, or hash
function getEmailFromUrl(availableDomains = []) {
  try {
    const defaultDomain = availableDomains[0] || 'mailflatimo.web.id';
    const path = decodeURIComponent(window.location.pathname).replace(/^\/+/, '').trim();

    // 1. Path: /inbox/budi@domain.com or /budi@domain.com
    if (path.startsWith('inbox/')) {
      const candidate = path.substring(6).trim();
      if (candidate.includes('@')) {
        return candidate.toLowerCase();
      } else if (candidate.length > 0) {
        // e.g. /inbox/budi -> budi@defaultDomain
        return `${candidate.toLowerCase()}@${defaultDomain}`;
      }
    } else if (path.includes('@')) {
      return path.toLowerCase();
    }

    // 2. Query param: ?email=budi@domain.com or ?inbox=budi@domain.com
    const params = new URLSearchParams(window.location.search);
    const qEmail = params.get('email') || params.get('inbox') || params.get('e');
    if (qEmail && qEmail.includes('@')) {
      return qEmail.trim().toLowerCase();
    }

    // 3. Hash: #budi@domain.com or #inbox/budi@domain.com
    const hash = decodeURIComponent(window.location.hash).replace(/^#\/?(inbox\/)?/, '').trim();
    if (hash.includes('@')) {
      return hash.toLowerCase();
    }
  } catch (e) {}
  return null;
}

export default function App() {
  const [activeTab, setActiveTab] = useState('inbox'); // 'inbox', 'api', 'dns', 'domains'
  const [domains, setDomains] = useState(['mailflatimo.web.id']);
  const [currentUsername, setCurrentUsername] = useState('spark.runner101');
  const [currentDomain, setCurrentDomain] = useState('mailflatimo.web.id');
  const [currentEmail, setCurrentEmail] = useState('spark.runner101@mailflatimo.web.id');
  
  const [messages, setMessages] = useState([]);
  const [selectedMessage, setSelectedMessage] = useState(null);
  const [isLoadingMessage, setIsLoadingMessage] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const [soundEnabled, setSoundEnabled] = useState(true);
  const [isQrModalOpen, setIsQrModalOpen] = useState(false);
  const [isTestModalOpen, setIsTestModalOpen] = useState(false);
  const [toasts, setToasts] = useState([]);
  const [stats, setStats] = useState(null);

  const eventSourceRef = useRef(null);

  // Helper toast notification
  const addToast = (type, title, message, subtitle) => {
    const id = Date.now().toString() + Math.random().toString(36).substring(2, 6);
    setToasts(prev => [...prev, { id, type, title, message, subtitle }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4500);
  };

  const removeToast = (id) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  // Helper update browser URL seamlessly without reload
  const updateUrlForEmail = (email) => {
    if (!email) return;
    try {
      const targetPath = `/inbox/${email}`;
      if (window.location.pathname !== targetPath) {
        window.history.replaceState({ email }, '', targetPath);
      }
    } catch (e) {}
  };

  // 1. Initial Load: Load domains & direct URL routing
  useEffect(() => {
    async function init() {
      try {
        let activeDomains = ['mailflatimo.web.id'];
        const domData = await fetchDomains();
        if (domData.success && domData.domains.length > 0) {
          setDomains(domData.domains);
          activeDomains = domData.domains;
        }

        // Check if user entered via direct URL (e.g. https://mailflatimo.web.id/inbox/budi@domain.com)
        const urlEmail = getEmailFromUrl(activeDomains);

        if (urlEmail && urlEmail.includes('@')) {
          const [user, dom] = urlEmail.split('@');
          setCurrentUsername(user);
          setCurrentDomain(dom);
          setCurrentEmail(urlEmail);
          localStorage.setItem('flatimo_email', urlEmail);
          updateUrlForEmail(urlEmail);
          loadMessages(urlEmail);
        } else {
          // Restore saved or generate new
          const savedEmail = localStorage.getItem('flatimo_email');
          if (savedEmail && savedEmail.includes('@')) {
            const [user, dom] = savedEmail.split('@');
            setCurrentUsername(user);
            setCurrentDomain(dom);
            setCurrentEmail(savedEmail);
            updateUrlForEmail(savedEmail);
            loadMessages(savedEmail);
          } else {
            handleGenerateRandom(activeDomains[0]);
          }
        }

        // Fetch stats
        const st = await fetchStats();
        if (st.success) setStats(st.stats);
      } catch (err) {
        console.error('Init error:', err);
      }
    }
    init();

    // Listen to browser Back / Forward buttons
    const handlePopState = (event) => {
      const emailFromNav = event.state?.email || getEmailFromUrl(domains);
      if (emailFromNav && emailFromNav.includes('@')) {
        const [user, dom] = emailFromNav.split('@');
        setCurrentUsername(user);
        setCurrentDomain(dom);
        setCurrentEmail(emailFromNav);
        loadMessages(emailFromNav);
      }
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // 2. Load messages for an inbox
  const loadMessages = async (email) => {
    if (!email) return;
    setIsRefreshing(true);
    try {
      const data = await fetchMessages(email);
      if (data.success) {
        setMessages(data.messages || []);
      }
    } catch (err) {
      console.error('Fetch messages error:', err);
    } finally {
      setIsRefreshing(false);
    }
  };

  // 3. Real-time Live SSE Connection
  useEffect(() => {
    if (!currentEmail) return;

    // Close previous stream
    if (eventSourceRef.current) {
      eventSourceRef.current.close();
    }

    const sseUrl = `/api/v1/inbox/${encodeURIComponent(currentEmail)}/stream`;
    const es = new EventSource(sseUrl);
    eventSourceRef.current = es;

    es.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === 'NEW_MAIL') {
          const newMsg = data.message;
          
          // Prepend to messages list
          setMessages(prev => {
            if (prev.some(m => m.id === newMsg.id)) return prev;
            return [
              {
                id: newMsg.id,
                inboxEmail: newMsg.inboxEmail,
                from: newMsg.from,
                subject: newMsg.subject,
                snippet: (newMsg.text || '').substring(0, 150).trim(),
                date: newMsg.date,
                read: false,
                hasAttachments: newMsg.attachments && newMsg.attachments.length > 0,
                attachmentCount: (newMsg.attachments || []).length,
                size: newMsg.size,
                createdAt: newMsg.createdAt
              },
              ...prev
            ];
          });

          // Play Sound Alert
          if (soundEnabled) {
            playMailSound();
          }

          // Trigger Glowing Toast Notification
          addToast(
            'mail',
            '⚡ Pesan Baru Tiba!',
            newMsg.subject || '(Tanpa Subjek)',
            `Dari: ${newMsg.from?.name || newMsg.from?.address || newMsg.from?.text}`
          );
        } else if (data.type === 'DELETE_MAIL') {
          setMessages(prev => prev.filter(m => m.id !== data.messageId));
          if (selectedMessage?.id === data.messageId) {
            setSelectedMessage(null);
          }
        }
      } catch (err) {
        console.error('SSE Message parsing error:', err);
      }
    };

    es.onerror = () => {
      // Reconnect handled automatically by EventSource
    };

    return () => {
      es.close();
    };
  }, [currentEmail, soundEnabled, selectedMessage]);

  // 4. Handlers
  const handleGenerateRandom = async (targetDomain) => {
    try {
      setIsRefreshing(true);
      setSelectedMessage(null);
      const data = await generateInbox(targetDomain || currentDomain);
      if (data.success) {
        setCurrentUsername(data.username);
        setCurrentDomain(data.domain);
        setCurrentEmail(data.email);
        localStorage.setItem('flatimo_email', data.email);
        updateUrlForEmail(data.email);
        setMessages([]);
        loadMessages(data.email);
      }
    } catch (err) {
      console.error('Generate random error:', err);
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleChangeCustom = async (username, domain) => {
    try {
      setIsRefreshing(true);
      setSelectedMessage(null);
      const data = await createCustomInbox(username, domain);
      if (data.success) {
        setCurrentUsername(data.username);
        setCurrentDomain(data.domain);
        setCurrentEmail(data.email);
        localStorage.setItem('flatimo_email', data.email);
        updateUrlForEmail(data.email);
        setMessages([]);
        loadMessages(data.email);
      }
    } catch (err) {
      alert(err.message || 'Gagal mengubah inbox');
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleDeleteInbox = async () => {
    if (window.confirm(`Bersihkan dan hapus seluruh pesan pada ${currentEmail}?`)) {
      try {
        await apiDeleteInbox(currentEmail);
        setMessages([]);
        setSelectedMessage(null);
        addToast('info', 'Kotak Masuk Dikosongkan', `Semua pesan pada ${currentEmail} telah dibersihkan.`);
      } catch (err) {
        alert('Gagal menghapus inbox: ' + err.message);
      }
    }
  };

  const handleSelectMessage = async (id) => {
    setIsLoadingMessage(true);
    try {
      const data = await fetchMessageDetail(id);
      if (data.success) {
        setSelectedMessage(data.message);
        setMessages(prev => prev.map(m => m.id === id ? { ...m, read: true } : m));
      }
    } catch (err) {
      alert('Gagal memuat pesan: ' + err.message);
    } finally {
      setIsLoadingMessage(false);
    }
  };

  const handleDeleteSingleMessage = async (id) => {
    try {
      await apiDeleteMessage(id);
      setMessages(prev => prev.filter(m => m.id !== id));
      if (selectedMessage?.id === id) {
        setSelectedMessage(null);
      }
    } catch (err) {
      alert('Gagal menghapus pesan: ' + err.message);
    }
  };

  const handleAddDomain = async (domain) => {
    const res = await apiAddDomain(domain);
    if (res.success) {
      setDomains(res.domains);
    }
    return res;
  };

  const handleDeleteDomain = async (domain) => {
    if (window.confirm(`Hapus domain ${domain}?`)) {
      const res = await apiDeleteDomain(domain);
      if (res.success) {
        setDomains(res.domains);
      }
    }
  };

  const unreadCount = messages.filter(m => !m.read).length;

  // Dynamic Browser Tab Title with Vector Lightning
  useEffect(() => {
    if (unreadCount > 0) {
      document.title = `(${unreadCount}) ⚡ Flatimo Mail`;
    } else {
      document.title = 'Flatimo Mail ⚡';
    }
  }, [unreadCount]);

  return (
    <div className="relative min-h-screen flex flex-col bg-dark-950 text-slate-100 selection:bg-brand-yellow/30 selection:text-brand-yellow overflow-x-hidden">
      
      {/* Animated Cyberpunk Moving Pixel Grid Background */}
      <PixelBackground />

      {/* Top Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        soundEnabled={soundEnabled}
        setSoundEnabled={setSoundEnabled}
        onOpenTestModal={() => setIsTestModalOpen(true)}
        domainCount={domains.length}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* TAB 1: INBOX */}
        {activeTab === 'inbox' && (
          <div>
            <InboxGenerator
              currentEmail={currentEmail}
              currentUsername={currentUsername}
              currentDomain={currentDomain}
              domains={domains}
              onGenerateRandom={() => handleGenerateRandom()}
              onChangeCustom={handleChangeCustom}
              onDeleteInbox={handleDeleteInbox}
              onRefreshMessages={() => loadMessages(currentEmail)}
              onOpenQrModal={() => setIsQrModalOpen(true)}
              totalEmails={messages.length}
              unreadEmails={unreadCount}
              isRefreshing={isRefreshing}
              onCopySuccess={(copied) => addToast('info', 'Alamat Disalin! 📋', copied)}
            />

            {/* If viewing single message */}
            {selectedMessage ? (
              <MessageViewer
                message={selectedMessage}
                isLoading={isLoadingMessage}
                onBack={() => setSelectedMessage(null)}
                onDelete={handleDeleteSingleMessage}
              />
            ) : (
              <MessageList
                messages={messages}
                onSelectMessage={handleSelectMessage}
                onDeleteMessage={handleDeleteSingleMessage}
                onOpenTestModal={() => setIsTestModalOpen(true)}
                selectedMessageId={selectedMessage?.id}
              />
            )}
          </div>
        )}

        {/* TAB 2: PUBLIC API DOCS */}
        {activeTab === 'api' && <ApiDocs />}

        {/* TAB 3: DNS SETUP GUIDE */}
        {activeTab === 'dns' && <DnsGuide />}

      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-dark-950 py-6 mt-12 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="text-brand-yellow font-bold">⚡ Flatimo Mail</span>
            <span>·</span>
            <span>Penerimaan Email Berkecepatan Tinggi (MX Priority 1)</span>
          </div>

          <div>
            <span>Pesan otomatis dihapus setelah 24 jam · 100% Bebas & Gratis</span>
          </div>
        </div>
      </footer>

      {/* Modals & Floating Toasts */}
      <QrModal
        email={currentEmail}
        isOpen={isQrModalOpen}
        onClose={() => setIsQrModalOpen(false)}
      />

      <TestEmailModal
        currentEmail={currentEmail}
        isOpen={isTestModalOpen}
        onClose={() => setIsTestModalOpen(false)}
        onSuccess={() => loadMessages(currentEmail)}
      />

      <Toast toasts={toasts} onDismiss={removeToast} />

    </div>
  );
}
