import React, { useState, useEffect, useRef } from 'react';
import { 
  ArrowLeft, 
  Trash2, 
  Download, 
  FileText, 
  Code, 
  Paperclip, 
  Printer, 
  Clock, 
  User, 
  ShieldCheck, 
  ExternalLink 
} from 'lucide-react';

export default function MessageViewer({
  message,
  onBack,
  onDelete,
  isLoading = false
}) {
  const [viewTab, setViewTab] = useState('html'); // 'html', 'text', 'headers', 'attachments'
  const iframeRef = useRef(null);

  useEffect(() => {
    // When switching to HTML or message changes, adjust iframe height
    if (viewTab === 'html' && iframeRef.current && message?.html) {
      const iframe = iframeRef.current;
      const handleResize = () => {
        try {
          if (iframe.contentWindow?.document?.body) {
            const height = iframe.contentWindow.document.body.scrollHeight;
            iframe.style.height = `${Math.max(height + 40, 300)}px`;
          }
        } catch {
          // Cross-origin fallback
        }
      };

      iframe.onload = handleResize;
    }
  }, [viewTab, message]);

  if (isLoading) {
    return (
      <div className="w-full max-w-4xl mx-auto mt-4 sm:mt-6 p-8 sm:p-12 text-center rounded-2xl sm:rounded-3xl bg-dark-900 border border-slate-800">
        <div className="w-8 h-8 border-2 border-brand-yellow border-t-transparent rounded-full animate-spin mx-auto mb-4" />
        <p className="text-xs sm:text-sm text-slate-400 font-semibold">Memuat isi pesan...</p>
      </div>
    );
  }

  if (!message) return null;

  const senderDisplay = message.from?.name ? `"${message.from.name}" <${message.from.address}>` : (message.from?.address || message.from?.text || 'Pengirim');
  const dateFormatted = new Date(message.date).toLocaleString('id-ID', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  const attachments = message.attachments || [];

  return (
    <div className="w-full max-w-4xl mx-auto mt-4 sm:mt-6 px-1 sm:px-0 animate-in fade-in slide-in-from-bottom-3 duration-200">
      <div className="rounded-2xl sm:rounded-3xl bg-dark-900 border border-brand-yellow/25 shadow-glow-yellow-sm overflow-hidden backdrop-blur-xl">
        
        {/* Navigation & Action Bar */}
        <div className="flex flex-wrap items-center justify-between gap-2.5 px-4 sm:px-6 py-3 sm:py-4 border-b border-slate-800 bg-dark-950/60">
          <button
            onClick={onBack}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg sm:rounded-xl bg-dark-850 border border-slate-700 hover:border-brand-yellow/50 text-slate-300 hover:text-brand-yellow text-xs font-bold transition-all active:scale-95"
          >
            <ArrowLeft className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            <span>Kembali</span>
          </button>

          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Download EML */}
            <a
              href={`/api/v1/messages/${message.id}/raw`}
              download={`mail-${message.id}.eml`}
              title="Unduh file mentah (.eml)"
              className="flex items-center gap-1 px-2.5 sm:px-3 py-1.5 rounded-lg sm:rounded-xl bg-dark-850 border border-slate-700 hover:border-slate-500 text-slate-300 text-xs font-semibold transition-all"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden xs:inline">EML</span>
            </a>

            {/* Print */}
            <button
              onClick={() => window.print()}
              title="Cetak pesan"
              className="p-1.5 sm:p-2 rounded-lg sm:rounded-xl bg-dark-850 border border-slate-700 hover:border-slate-500 text-slate-400 hover:text-slate-200 text-xs transition-all"
            >
              <Printer className="w-3.5 h-3.5" />
            </button>

            {/* Delete Message */}
            <button
              onClick={() => onDelete(message.id)}
              title="Hapus pesan ini"
              className="flex items-center gap-1 px-2.5 sm:px-3 py-1.5 rounded-lg sm:rounded-xl bg-rose-500/10 border border-rose-500/30 hover:bg-rose-500/20 text-rose-400 text-xs font-bold transition-all active:scale-95"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Hapus</span>
            </button>
          </div>
        </div>

        {/* Header Details */}
        <div className="p-4 sm:p-7 md:p-8 border-b border-slate-800/80 bg-gradient-to-b from-dark-900 to-dark-950/40">
          
          <h1 className="text-lg sm:text-2xl font-black text-white mb-3 sm:mb-4 leading-snug break-words">
            {message.subject || '(Tanpa Subjek)'}
          </h1>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            {/* Sender */}
            <div className="flex items-start gap-2.5">
              <div className="p-1.5 rounded-lg bg-brand-yellow/10 text-brand-yellow shrink-0 mt-0.5">
                <User className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
              </div>
              <div className="min-w-0">
                <span className="text-slate-500 block font-medium text-[11px]">Dari:</span>
                <span className="font-semibold text-slate-200 font-mono break-all text-xs">
                  {senderDisplay}
                </span>
              </div>
            </div>

            {/* Date */}
            <div className="flex items-start gap-2.5 sm:justify-end">
              <div className="p-1.5 rounded-lg bg-brand-orange/10 text-brand-orange shrink-0 mt-0.5">
                <Clock className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
              </div>
              <div>
                <span className="text-slate-500 block font-medium text-[11px]">Waktu:</span>
                <span className="font-semibold text-slate-300 text-xs">
                  {dateFormatted}
                </span>
              </div>
            </div>
          </div>

          {/* Recipient Tag */}
          <div className="mt-3 sm:mt-4 pt-3 border-t border-slate-800/60 flex items-center gap-2 text-xs">
            <span className="text-slate-500 text-[11px]">Tujuan:</span>
            <span className="font-mono text-brand-yellow font-semibold bg-brand-yellow/10 px-2.5 py-0.5 rounded-md border border-brand-yellow/20 text-xs break-all">
              {message.inboxEmail}
            </span>
          </div>

        </div>

        {/* View Tabs (Scrollable on Mobile) */}
        <div className="flex items-center gap-1 sm:gap-2 px-4 sm:px-6 pt-3 sm:pt-4 border-b border-slate-800 bg-dark-950/40 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setViewTab('html')}
            className={`flex items-center gap-1.5 px-3 sm:px-4 py-2 text-xs font-bold border-b-2 whitespace-nowrap shrink-0 transition-all ${
              viewTab === 'html'
                ? 'border-brand-yellow text-brand-yellow'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Format HTML</span>
          </button>

          <button
            onClick={() => setViewTab('text')}
            className={`flex items-center gap-1.5 px-3 sm:px-4 py-2 text-xs font-bold border-b-2 whitespace-nowrap shrink-0 transition-all ${
              viewTab === 'text'
                ? 'border-brand-yellow text-brand-yellow'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Code className="w-3.5 h-3.5" />
            <span>Teks Biasa</span>
          </button>

          {attachments.length > 0 && (
            <button
              onClick={() => setViewTab('attachments')}
              className={`flex items-center gap-1.5 px-3 sm:px-4 py-2 text-xs font-bold border-b-2 whitespace-nowrap shrink-0 transition-all ${
                viewTab === 'attachments'
                  ? 'border-brand-yellow text-brand-yellow'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Paperclip className="w-3.5 h-3.5" />
              <span>Lampiran ({attachments.length})</span>
            </button>
          )}

          <button
            onClick={() => setViewTab('headers')}
            className={`flex items-center gap-1.5 px-3 sm:px-4 py-2 text-xs font-bold border-b-2 whitespace-nowrap shrink-0 transition-all ${
              viewTab === 'headers'
                ? 'border-brand-yellow text-brand-yellow'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>Header Teknis</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-3.5 sm:p-6">
          
          {/* HTML VIEW */}
          {viewTab === 'html' && (
            <div>
              {message.html ? (
                <div className="bg-white rounded-xl sm:rounded-2xl p-2.5 sm:p-4 overflow-x-auto border border-slate-700 shadow-inner -webkit-overflow-scrolling-touch">
                  <iframe
                    ref={iframeRef}
                    title="Email HTML Body"
                    srcDoc={`
                      <!DOCTYPE html>
                      <html>
                        <head>
                          <meta charset="utf-8">
                          <meta name="viewport" content="width=device-width, initial-scale=1.0">
                          <style>
                            body {
                              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
                              color: #1e293b;
                              margin: 0;
                              padding: 8px;
                              word-wrap: break-word;
                              font-size: 14px;
                            }
                            img { max-width: 100%; height: auto; }
                            a { color: #f59e0b; }
                          </style>
                        </head>
                        <body>
                          ${message.html}
                        </body>
                      </html>
                    `}
                    sandbox="allow-popups allow-popups-to-escape-sandbox allow-same-origin"
                    className="w-full min-h-[300px] border-0"
                  />
                </div>
              ) : (
                <div className="p-5 sm:p-8 rounded-xl sm:rounded-2xl bg-dark-950 border border-slate-800 text-slate-300 font-mono text-xs sm:text-sm whitespace-pre-wrap leading-relaxed">
                  {message.text || '(Tidak ada konten teks)'}
                </div>
              )}
            </div>
          )}

          {/* TEXT VIEW */}
          {viewTab === 'text' && (
            <div className="p-4 sm:p-6 rounded-xl sm:rounded-2xl bg-dark-950 border border-slate-800 text-slate-300 font-mono text-xs sm:text-sm whitespace-pre-wrap leading-relaxed select-text">
              {message.text || message.textAsHtml || '(Tidak ada konten teks biasa)'}
            </div>
          )}

          {/* ATTACHMENTS VIEW */}
          {viewTab === 'attachments' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
              {attachments.map((att) => (
                <div
                  key={att.id}
                  className="flex items-center justify-between p-3 sm:p-4 rounded-xl sm:rounded-2xl bg-dark-950 border border-slate-800 hover:border-brand-yellow/40 transition-all"
                >
                  <div className="flex items-center gap-2.5 truncate">
                    <div className="p-2 rounded-lg sm:rounded-xl bg-brand-yellow/10 text-brand-yellow shrink-0">
                      <Paperclip className="w-4 h-4 sm:w-5 sm:h-5" />
                    </div>
                    <div className="truncate">
                      <span className="font-semibold text-xs sm:text-sm text-white block truncate">
                        {att.filename}
                      </span>
                      <span className="text-[10px] sm:text-xs text-slate-500 font-mono">
                        {(att.size / 1024).toFixed(1)} KB · {att.contentType}
                      </span>
                    </div>
                  </div>

                  <a
                    href={`/api/v1/messages/${message.id}/attachments/${att.id}`}
                    download={att.filename}
                    className="p-2 rounded-lg sm:rounded-xl bg-brand-yellow/10 hover:bg-brand-yellow text-brand-yellow hover:text-dark-950 transition-all shrink-0 ml-2"
                    title="Unduh lampiran ini"
                  >
                    <Download className="w-4 h-4" />
                  </a>
                </div>
              ))}
            </div>
          )}

          {/* HEADERS VIEW */}
          {viewTab === 'headers' && (
            <div className="p-4 sm:p-6 rounded-xl sm:rounded-2xl bg-dark-950 border border-slate-800 overflow-x-auto">
              <pre className="font-mono text-[11px] sm:text-xs text-slate-400 leading-relaxed whitespace-pre-wrap">
                {JSON.stringify(message.headers, null, 2)}
              </pre>
            </div>
          )}

        </div>

      </div>
    </div>
  );
}
