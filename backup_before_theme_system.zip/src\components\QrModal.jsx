import React from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { X, Copy, Check, QrCode as QrIcon } from 'lucide-react';

export default function QrModal({ email, isOpen, onClose }) {
  const [copied, setCopied] = React.useState(false);

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(email);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-dark-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-sm rounded-3xl bg-dark-900 border border-brand-yellow/40 shadow-glow-yellow p-6 text-center">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-white bg-dark-950 border border-slate-800"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center justify-center gap-2 mb-4 text-brand-yellow">
          <QrIcon className="w-5 h-5" />
          <h3 className="font-bold text-base text-white">Pindai QR Code Inbox</h3>
        </div>

        {/* QR Code Container */}
        <div className="p-4 bg-white rounded-2xl inline-block mb-4 shadow-xl border-4 border-brand-yellow/20">
          <QRCodeSVG
            value={`mailto:${email}`}
            size={180}
            level="H"
            includeMargin={true}
          />
        </div>

        {/* Email Address */}
        <div className="font-mono text-xs font-bold text-brand-yellow break-all bg-dark-950 p-2.5 rounded-xl border border-slate-800 mb-4 select-all">
          {email}
        </div>

        {/* Copy Button */}
        <button
          onClick={handleCopy}
          className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl font-bold text-xs text-dark-950 glow-btn-yellow"
        >
          {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
          <span>{copied ? 'Tersalin ke Clipboard!' : 'Salin Alamat Email'}</span>
        </button>

      </div>
    </div>
  );
}
