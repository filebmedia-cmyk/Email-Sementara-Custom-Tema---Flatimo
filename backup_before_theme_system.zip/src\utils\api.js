const BASE_URL = '/api/v1';

export async function fetchDomains() {
  const res = await fetch(`${BASE_URL}/domains`);
  return res.json();
}

export async function fetchDomainStatuses() {
  const res = await fetch(`${BASE_URL}/domains/status`);
  return res.json();
}

export async function checkDomainSync(domain) {
  const res = await fetch(`${BASE_URL}/domains/sync-check`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ domain }),
  });
  return res.json();
}

export async function addDomain(domain) {
  const res = await fetch(`${BASE_URL}/domains`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ domain }),
  });
  return res.json();
}

export async function deleteDomain(domain) {
  const res = await fetch(`${BASE_URL}/domains/${encodeURIComponent(domain)}`, {
    method: 'DELETE',
  });
  return res.json();
}

export async function generateInbox(domain = '') {
  const url = domain ? `${BASE_URL}/inbox/generate?domain=${encodeURIComponent(domain)}` : `${BASE_URL}/inbox/generate`;
  const res = await fetch(url);
  return res.json();
}

export async function createCustomInbox(username, domain) {
  const res = await fetch(`${BASE_URL}/inbox/create`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, domain }),
  });
  return res.json();
}

export async function fetchMessages(email) {
  const res = await fetch(`${BASE_URL}/inbox/${encodeURIComponent(email)}/messages`);
  return res.json();
}

export async function fetchMessageDetail(id) {
  const res = await fetch(`${BASE_URL}/messages/${id}`);
  return res.json();
}

export async function deleteMessage(id) {
  const res = await fetch(`${BASE_URL}/messages/${id}`, {
    method: 'DELETE',
  });
  return res.json();
}

export async function deleteInbox(email) {
  const res = await fetch(`${BASE_URL}/inbox/${encodeURIComponent(email)}`, {
    method: 'DELETE',
  });
  return res.json();
}

export async function sendTestEmail(payload) {
  const res = await fetch(`${BASE_URL}/test-email`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  return res.json();
}

export async function fetchStats() {
  const res = await fetch(`${BASE_URL}/stats`);
  return res.json();
}
