import React, { useState } from 'react';
import { Terminal, Copy, Check, Play, Book, Code2, Zap, Key, ShieldCheck } from 'lucide-react';

export default function ApiDocs() {
  const [langTab, setLangTab] = useState('curl'); // 'curl', 'js', 'python'
  const [apiKey, setApiKey] = useState('FLATIMOSTORE');
  const [copiedIndex, setCopiedIndex] = useState(null);
  const [copiedKey, setCopiedKey] = useState(false);
  const [testResponse, setTestResponse] = useState(null);
  const [testingEndpoint, setTestingEndpoint] = useState(null);

  const baseUrl = window.location.origin;

  const endpoints = [
    {
      id: 'verify-key',
      method: 'GET',
      path: `/api/v1/key/verify?key=${apiKey}`,
      title: '0. Verifikasi API Key (FLATIMOSTORE)',
      desc: 'Memvalidasi status lisensi API key dan memeriksa kuota / status VIP.',
      curl: `curl -X GET "${baseUrl}/api/v1/key/verify?key=${apiKey}" \\
  -H "X-API-Key: ${apiKey}"`,
      js: `const res = await fetch("${baseUrl}/api/v1/key/verify?key=${apiKey}", {
  headers: { "X-API-Key": "${apiKey}" }
});
const data = await res.json();
console.log("Status Key:", data);`,
      python: `import requests
res = requests.get("${baseUrl}/api/v1/key/verify", 
  headers={"X-API-Key": "${apiKey}"},
  params={"key": "${apiKey}"}
)
print(res.json())`
    },
    {
      id: 'get-domains',
      method: 'GET',
      path: '/api/v1/domains',
      title: '1. Daftar Domain Aktif',
      desc: 'Mengambil seluruh daftar domain yang aktif dan tersedia untuk digunakan.',
      curl: `curl -X GET "${baseUrl}/api/v1/domains" \\
  -H "X-API-Key: ${apiKey}"`,
      js: `const res = await fetch("${baseUrl}/api/v1/domains", {
  headers: { "X-API-Key": "${apiKey}" }
});
const data = await res.json();
console.log(data);`,
      python: `import requests
res = requests.get("${baseUrl}/api/v1/domains", headers={"X-API-Key": "${apiKey}"})
print(res.json())`
    },
    {
      id: 'generate-inbox',
      method: 'GET',
      path: '/api/v1/inbox/generate',
      title: '2. Generate Email Acak Instan',
      desc: 'Membuat alamat email sementara acak baru secara otomatis.',
      curl: `curl -X GET "${baseUrl}/api/v1/inbox/generate" \\
  -H "X-API-Key: ${apiKey}"`,
      js: `const res = await fetch("${baseUrl}/api/v1/inbox/generate", {
  headers: { "X-API-Key": "${apiKey}" }
});
const inbox = await res.json();
console.log("Email baru:", inbox.email);`,
      python: `import requests
res = requests.get("${baseUrl}/api/v1/inbox/generate", headers={"X-API-Key": "${apiKey}"})
inbox = res.json()
print("Email:", inbox['email'])`
    },
    {
      id: 'create-inbox',
      method: 'POST',
      path: '/api/v1/inbox/create',
      title: '3. Buat Custom Email Inbox',
      desc: 'Membuat alamat email khusus sesuai dengan nama username atau email yang Anda tentukan.',
      curl: `curl -X POST "${baseUrl}/api/v1/inbox/create" \\
  -H "Content-Type: application/json" \\
  -H "X-API-Key: ${apiKey}" \\
  -d '{"username": "developer_test", "domain": "mailflatimo.web.id"}'`,
      js: `const res = await fetch("${baseUrl}/api/v1/inbox/create", {
  method: "POST",
  headers: { 
    "Content-Type": "application/json",
    "X-API-Key": "${apiKey}"
  },
  body: JSON.stringify({
    username: "developer_test",
    domain: "mailflatimo.web.id"
  })
});
const result = await res.json();
console.log(result);`,
      python: `import requests
res = requests.post("${baseUrl}/api/v1/inbox/create", 
  headers={"X-API-Key": "${apiKey}"},
  json={
    "username": "developer_test",
    "domain": "mailflatimo.web.id"
  }
)
print(res.json())`
    },
    {
      id: 'get-messages',
      method: 'GET',
      path: '/api/v1/inbox/:email/messages',
      title: '4. Ambil Daftar Pesan Masuk',
      desc: 'Mengambil semua email yang masuk pada inbox tertentu.',
      curl: `curl -X GET "${baseUrl}/api/v1/inbox/test@mailflatimo.web.id/messages" \\
  -H "X-API-Key: ${apiKey}"`,
      js: `const email = "test@mailflatimo.web.id";
const res = await fetch(\`${baseUrl}/api/v1/inbox/\${encodeURIComponent(email)}/messages\`, {
  headers: { "X-API-Key": "${apiKey}" }
});
const data = await res.json();
console.log(\`Total pesan: \${data.total}\`, data.messages);`,
      python: `import requests
email = "test@mailflatimo.web.id"
res = requests.get(f"${baseUrl}/api/v1/inbox/{email}/messages", headers={"X-API-Key": "${apiKey}"})
data = res.json()
print("Pesan:", data.get("messages", []))`
    },
    {
      id: 'get-message-detail',
      method: 'GET',
      path: '/api/v1/messages/:id',
      title: '5. Ambil Detail & Isi Email (HTML/Text)',
      desc: 'Membaca isi lengkap pesan termasuk format HTML, teks polos, headers, dan lampiran.',
      curl: `curl -X GET "${baseUrl}/api/v1/messages/MESSAGE_ID" \\
  -H "X-API-Key: ${apiKey}"`,
      js: `// Ganti MESSAGE_ID dengan ID pesan asli dari inbox Anda
const messageId = "L5WxJFdThJyC";
const res = await fetch(\`${baseUrl}/api/v1/messages/\${messageId}\`, {
  headers: { "X-API-Key": "${apiKey}" }
});
const data = await res.json();
console.log("Subjek:", data.message?.subject);
console.log("HTML:", data.message?.html);`,
      python: `import requests
# Ganti msg_id dengan ID pesan asli dari inbox Anda
msg_id = "L5WxJFdThJyC"
res = requests.get(f"${baseUrl}/api/v1/messages/{msg_id}", headers={"X-API-Key": "${apiKey}"})
print(res.json())`
    },
    {
      id: 'stream-sse',
      method: 'GET (SSE)',
      path: '/api/v1/inbox/:email/stream',
      title: '6. Real-time Live Stream (Server-Sent Events)',
      desc: 'Menerima notifikasi seketika saat ada email baru masuk tanpa perlu polling berulang.',
      curl: `curl -N "${baseUrl}/api/v1/inbox/test@mailflatimo.web.id/stream" \\
  -H "X-API-Key: ${apiKey}"`,
      js: `const eventSource = new EventSource("${baseUrl}/api/v1/inbox/test@mailflatimo.web.id/stream");
eventSource.onmessage = (event) => {
  const data = JSON.parse(event.data);
  if (data.type === "NEW_MAIL") {
    console.log("⚡ Email Baru Masuk:", data.message.subject);
  }
};`,
      python: `# Python SSE Client
import requests
url = "${baseUrl}/api/v1/inbox/test@mailflatimo.web.id/stream"
with requests.get(url, stream=True, headers={"X-API-Key": "${apiKey}"}) as response:
    for line in response.iter_lines():
        if line:
            print("Event:", line.decode("utf-8"))`
    }
  ];

  const handleCopyCode = (text, idx) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(idx);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const handleCopyApiKey = () => {
    navigator.clipboard.writeText(apiKey);
    setCopiedKey(true);
    setTimeout(() => setCopiedKey(false), 2000);
  };

  const handleRunTest = async (ep) => {
    setTestingEndpoint(ep.id);
    setTestResponse(null);
    try {
      if (ep.id === 'get-message-detail') {
        // Find existing message or generate one for test
        const listRes = await fetch('/api/v1/inbox/spark.runner101@mailflatimo.web.id/messages', {
          headers: { 'X-API-Key': apiKey }
        });
        const listData = await listRes.json();
        let targetId = listData.messages?.[0]?.id;

        if (!targetId) {
          // Generate a sample message
          const testMsgRes = await fetch('/api/v1/test-email', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-API-Key': apiKey },
            body: JSON.stringify({ to: 'spark.runner101@mailflatimo.web.id' })
          });
          const testMsgData = await testMsgRes.json();
          targetId = testMsgData.email?.id || 'sample_msg';
        }

        const res = await fetch(`/api/v1/messages/${targetId}`, {
          headers: { 'X-API-Key': apiKey }
        });
        const data = await res.json();
        setTestResponse({ endpoint: ep.id, status: res.status, data });
        return;
      }

      let url = ep.path.replace(':email', 'spark.runner101@mailflatimo.web.id');
      if (ep.method.startsWith('GET') && !ep.method.includes('SSE')) {
        const res = await fetch(url, {
          headers: { 'X-API-Key': apiKey }
        });
        const data = await res.json();
        setTestResponse({ endpoint: ep.id, status: res.status, data });
      } else if (ep.method === 'POST') {
        const res = await fetch(url, {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'X-API-Key': apiKey
          },
          body: JSON.stringify({ username: 'api_test_user', domain: 'mailflatimo.web.id' })
        });
        const data = await res.json();
        setTestResponse({ endpoint: ep.id, status: res.status, data });
      }
    } catch (err) {
      setTestResponse({ endpoint: ep.id, status: 'ERROR', data: { error: err.message } });
    } finally {
      setTestingEndpoint(null);
    }
  };

  return (
    <div className="w-full max-w-5xl mx-auto mt-4 sm:mt-6 px-1 sm:px-0 animate-in fade-in duration-300">
      
      {/* Header Banner */}
      <div className="rounded-2xl sm:rounded-3xl p-4 sm:p-7 md:p-8 bg-gradient-to-br from-dark-900 via-dark-950 to-dark-900 border border-brand-yellow/30 shadow-glow-yellow-sm mb-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <div className="p-2 rounded-xl bg-brand-yellow/10 text-brand-yellow">
                <Terminal className="w-5 h-5" />
              </div>
              <h1 className="text-2xl font-black text-white">Dokumentasi Public REST API</h1>
            </div>
            <p className="text-sm text-slate-400">
              Integrasikan penerimaan email sementara ke dalam bot Telegram, script testing, atau aplikasi otomatisasi Anda.
            </p>
          </div>

          <div className="flex items-center gap-2 bg-dark-950 p-1.5 rounded-xl border border-slate-800 self-start sm:self-center">
            <button
              onClick={() => setLangTab('curl')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                langTab === 'curl' ? 'bg-brand-yellow text-dark-950 shadow-glow-yellow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              cURL
            </button>
            <button
              onClick={() => setLangTab('js')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                langTab === 'js' ? 'bg-brand-yellow text-dark-950 shadow-glow-yellow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              JavaScript
            </button>
            <button
              onClick={() => setLangTab('python')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                langTab === 'python' ? 'bg-brand-yellow text-dark-950 shadow-glow-yellow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              Python
            </button>
          </div>
        </div>

        {/* API Key Box */}
        <div className="mt-6 pt-5 border-t border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-lg bg-brand-orange/20 text-brand-orange border border-brand-orange/30">
              <Key className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs text-slate-400 font-medium">Master API Key (VIP Unlimited):</span>
              <div className="font-mono font-bold text-sm text-brand-yellow flex items-center gap-2">
                <code>{apiKey}</code>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  LIFETIME VIP
                </span>
              </div>
            </div>
          </div>

          <button
            onClick={handleCopyApiKey}
            className="flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-xl bg-dark-950 border border-slate-700 hover:border-brand-yellow text-slate-200 hover:text-brand-yellow text-xs font-semibold transition-all active:scale-95 self-start sm:self-auto"
          >
            {copiedKey ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedKey ? 'Disalin!' : 'Salin API Key'}</span>
          </button>
        </div>
      </div>

      {/* Endpoints List */}
      <div className="space-y-5">
        {endpoints.map((ep, idx) => (
          <div 
            key={ep.id}
            className="rounded-2xl sm:rounded-3xl bg-dark-900/90 border border-slate-800 hover:border-brand-yellow/40 transition-all p-4 sm:p-6 backdrop-blur-xl"
          >
            {/* Header Endpoint */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
              <div className="flex items-center gap-2.5 flex-wrap">
                <span className={`px-2.5 py-1 rounded-lg text-xs font-bold font-mono ${
                  ep.method.startsWith('GET') 
                    ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                    : 'bg-brand-orange/15 text-brand-orange border border-brand-orange/30'
                }`}>
                  {ep.method}
                </span>
                <code className="font-mono text-sm font-bold text-white break-all">
                  {ep.path}
                </code>
              </div>

              {/* Action Test Button */}
              {!ep.method.includes('SSE') && (
                <button
                  onClick={() => handleRunTest(ep)}
                  disabled={testingEndpoint === ep.id}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-brand-yellow to-brand-orange text-dark-950 text-xs font-bold shadow-glow-yellow-sm hover:brightness-110 active:scale-95 transition-all self-start sm:self-auto"
                >
                  <Play className={`w-3.5 h-3.5 ${testingEndpoint === ep.id ? 'animate-spin' : 'fill-dark-950'}`} />
                  <span>{testingEndpoint === ep.id ? 'Menguji...' : 'Uji Endpoint'}</span>
                </button>
              )}
            </div>

            {/* Title & Desc */}
            <h3 className="text-base font-bold text-white mb-1">{ep.title}</h3>
            <p className="text-xs text-slate-400 mb-3">{ep.desc}</p>

            {/* Code Block Container */}
            <div className="relative rounded-xl bg-dark-950 border border-slate-800/80 p-3 sm:p-4 font-mono text-xs overflow-x-auto text-slate-300">
              <pre className="whitespace-pre-wrap break-all">
                {langTab === 'curl' && ep.curl}
                {langTab === 'js' && ep.js}
                {langTab === 'python' && ep.python}
              </pre>

              <button
                onClick={() => handleCopyCode(
                  langTab === 'curl' ? ep.curl : langTab === 'js' ? ep.js : ep.python,
                  idx
                )}
                className="absolute top-2.5 right-2.5 p-1.5 rounded-lg bg-dark-900 border border-slate-800 hover:border-brand-yellow/50 text-slate-400 hover:text-brand-yellow transition-all"
                title="Salin snippet"
              >
                {copiedIndex === idx ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>

            {/* Live Test Response Box */}
            {testResponse && testResponse.endpoint === ep.id && (
              <div className="mt-3 p-3 rounded-xl bg-dark-950 border border-brand-yellow/30 animate-in fade-in duration-200">
                <div className="flex items-center justify-between text-xs font-mono font-bold mb-2 pb-1.5 border-b border-slate-800">
                  <span className="text-slate-400">Response Status: <strong className="text-emerald-400">{testResponse.status}</strong></span>
                  <button 
                    onClick={() => setTestResponse(null)}
                    className="text-slate-500 hover:text-slate-300 text-[10px]"
                  >
                    Tutup
                  </button>
                </div>
                <pre className="font-mono text-xs text-brand-yellow/90 max-h-48 overflow-y-auto whitespace-pre-wrap break-all">
                  {JSON.stringify(testResponse.data, null, 2)}
                </pre>
              </div>
            )}

          </div>
        ))}
      </div>

    </div>
  );
}
