import React from 'react';
import { Zap, BookOpen, Server, Volume2, VolumeX, Send } from 'lucide-react';

export default function Header({ 
  activeTab, 
  setActiveTab, 
  soundEnabled, 
  setSoundEnabled, 
  onOpenTestModal
}) {
  return (
    <header className="sticky top-0 z-40 border-b border-brand-yellow/15 bg-dark-950/90 backdrop-blur-xl transition-all">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        
        {/* Main Header Bar */}
        <div className="flex items-center justify-between h-16 sm:h-20">
          
          {/* Brand Logo & Name */}
          <div 
            onClick={() => setActiveTab('inbox')}
            className="flex items-center gap-2 sm:gap-3 cursor-pointer group select-none shrink-0"
          >
            <div className="relative flex items-center justify-center w-9 h-9 sm:w-12 sm:h-12 rounded-xl sm:rounded-2xl bg-gradient-to-br from-brand-yellow/20 via-brand-orange/20 to-transparent border border-brand-yellow/40 shadow-glow-yellow-sm group-hover:shadow-glow-yellow transition-all duration-300">
              <svg 
                className="w-5 h-5 sm:w-7 sm:h-7 fill-brand-yellow drop-shadow-[0_0_8px_rgba(255,184,0,0.9)] animate-lightning-glow" 
                viewBox="0 0 24 24"
              >
                <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" />
              </svg>
            </div>

            <div>
              <div className="flex items-center gap-1.5 sm:gap-2">
                <span className="text-lg sm:text-2xl font-black tracking-tight text-white group-hover:text-brand-yellow transition-colors">
                  Flatimo<span className="text-brand-yellow">Mail</span>
                </span>
                <span className="text-[9px] sm:text-[10px] font-bold px-1.5 sm:px-2 py-0.5 rounded-full bg-brand-yellow/15 text-brand-yellow border border-brand-yellow/30 shadow-glow-yellow-sm">
                  ⚡ v1.0
                </span>
              </div>
              <p className="text-[10px] sm:text-xs text-slate-400 font-medium hidden xs:block">
                Lightning Fast Temp Mail
              </p>
            </div>
          </div>

          {/* Desktop & Laptop Navigation Tabs (3 Menu Ramping) */}
          <nav className="hidden md:flex items-center gap-1.5 p-1 rounded-xl bg-dark-900 border border-slate-800">
            <button
              onClick={() => setActiveTab('inbox')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                activeTab === 'inbox'
                  ? 'bg-gradient-to-r from-brand-yellow to-brand-orange text-dark-950 shadow-glow-yellow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-dark-800'
              }`}
            >
              <Zap className={`w-4 h-4 ${activeTab === 'inbox' ? 'fill-dark-950' : 'text-brand-yellow'}`} />
              Kotak Masuk
            </button>

            <button
              onClick={() => setActiveTab('api')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                activeTab === 'api'
                  ? 'bg-gradient-to-r from-brand-yellow to-brand-orange text-dark-950 shadow-glow-yellow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-dark-800'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              API Publik
            </button>

            <button
              onClick={() => setActiveTab('dns')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                activeTab === 'dns'
                  ? 'bg-gradient-to-r from-brand-yellow to-brand-orange text-dark-950 shadow-glow-yellow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-dark-800'
              }`}
            >
              <Server className="w-4 h-4" />
              Panduan DNS
            </button>
          </nav>

          {/* Action Tools */}
          <div className="flex items-center gap-2">
            {/* Quick Test Email Sender Button */}
            <button
              onClick={onOpenTestModal}
              title="Kirim email simulasi untuk uji coba instan"
              className="flex items-center gap-1.5 px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-lg sm:rounded-xl text-xs font-bold text-brand-yellow bg-brand-yellow/10 border border-brand-yellow/30 hover:bg-brand-yellow/20 hover:border-brand-yellow/60 transition-all shadow-glow-yellow-sm active:scale-95"
            >
              <Send className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Tes Email</span>
            </button>

            {/* Sound Toggle */}
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              title={soundEnabled ? 'Matikan Notifikasi Suara' : 'Aktifkan Notifikasi Suara'}
              className={`p-2 sm:p-2.5 rounded-lg sm:rounded-xl border transition-all active:scale-95 ${
                soundEnabled
                  ? 'bg-dark-850 border-brand-yellow/40 text-brand-yellow shadow-glow-yellow-sm'
                  : 'bg-dark-900 border-slate-800 text-slate-500 hover:text-slate-300'
              }`}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>
          </div>

        </div>

        {/* Mobile & Tablet Navigation Bar (3 Kolom Simetris Sempurna) */}
        <div className="grid md:hidden grid-cols-3 gap-1.5 py-2 border-t border-slate-800/80">
          
          {/* Kolom 1: Kotak Masuk */}
          <button
            onClick={() => setActiveTab('inbox')}
            className={`flex items-center justify-center gap-1.5 px-2 py-2 rounded-xl text-xs font-bold transition-all active:scale-95 ${
              activeTab === 'inbox' 
                ? 'bg-gradient-to-r from-brand-yellow to-brand-orange text-dark-950 shadow-glow-yellow-sm' 
                : 'text-slate-300 hover:text-white bg-dark-900 border border-slate-800'
            }`}
          >
            <Zap className={`w-3.5 h-3.5 ${activeTab === 'inbox' ? 'fill-dark-950' : 'text-brand-yellow'}`} />
            <span className="truncate">Kotak Masuk</span>
          </button>

          {/* Kolom 2: API Publik */}
          <button
            onClick={() => setActiveTab('api')}
            className={`flex items-center justify-center gap-1.5 px-2 py-2 rounded-xl text-xs font-bold transition-all active:scale-95 ${
              activeTab === 'api' 
                ? 'bg-gradient-to-r from-brand-yellow to-brand-orange text-dark-950 shadow-glow-yellow-sm' 
                : 'text-slate-300 hover:text-white bg-dark-900 border border-slate-800'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span className="truncate">API Publik</span>
          </button>

          {/* Kolom 3: Panduan DNS */}
          <button
            onClick={() => setActiveTab('dns')}
            className={`flex items-center justify-center gap-1.5 px-2 py-2 rounded-xl text-xs font-bold transition-all active:scale-95 ${
              activeTab === 'dns' 
                ? 'bg-gradient-to-r from-brand-yellow to-brand-orange text-dark-950 shadow-glow-yellow-sm' 
                : 'text-slate-300 hover:text-white bg-dark-900 border border-slate-800'
            }`}
          >
            <Server className="w-3.5 h-3.5" />
            <span className="truncate">Panduan DNS</span>
          </button>

        </div>

      </div>
    </header>
  );
}
