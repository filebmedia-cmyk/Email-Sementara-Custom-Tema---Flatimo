import dns from 'dns';
const { Resolver } = dns.promises;
import { db } from './db.js';
import { config } from './config.js';
import { eventBus } from './eventBus.js';

const BOT_TOKEN = '8930418014:AAH36qodGrL87Q3i6WukUBayuoGSKRaEvyY';
const ADMIN_ID = '6286514348';
const API_BASE = `http://127.0.0.1:${config.port || 3000}/api/v1`;
const API_KEY = 'FLATIMOSTORE';
const TG_API = `https://api.telegram.org/bot${BOT_TOKEN}`;

// State storage per user
const userSessions = new Map();
// Active registered domains to notify users when test email arrives
const domainWatchers = new Map(); // domain -> chatId

// Helper Telegram API calls
async function callTelegram(method, body) {
  try {
    const res = await fetch(`${TG_API}/${method}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    return await res.json();
  } catch (err) {
    console.error(`[TelegramBot Error] ${method}:`, err.message);
    return { ok: false, error: err.message };
  }
}

async function sendMessage(chatId, text, replyMarkup = null) {
  return await callTelegram('sendMessage', {
    chat_id: chatId,
    text,
    parse_mode: 'HTML',
    reply_markup: replyMarkup,
    disable_web_page_preview: true
  });
}

async function editMessage(chatId, messageId, text, replyMarkup = null) {
  return await callTelegram('editMessageText', {
    chat_id: chatId,
    message_id: messageId,
    text,
    parse_mode: 'HTML',
    reply_markup: replyMarkup,
    disable_web_page_preview: true
  });
}

async function deleteMessage(chatId, messageId) {
  if (!chatId || !messageId) return;
  try {
    await callTelegram('deleteMessage', {
      chat_id: chatId,
      message_id: messageId
    });
  } catch (e) {}
}

async function answerCallback(callbackQueryId, text = null) {
  return await callTelegram('answerCallbackQuery', {
    callback_query_id: callbackQueryId,
    text: text || undefined
  });
}

// Strict Real-World DNS MX Checker helper using 8.8.8.8 and 1.1.1.1
async function verifyDomainMx(domain) {
  const resolver = new Resolver();
  resolver.setServers(['8.8.8.8', '1.1.1.1']);

  try {
    const mxRecords = await resolver.resolveMx(domain);
    if (!mxRecords || mxRecords.length === 0) {
      return { 
        success: false, 
        reason: 'Record MX tidak ditemukan pada domain ini.',
        foundRecords: []
      };
    }

    // Sort by priority
    mxRecords.sort((a, b) => a.priority - b.priority);

    // Check if points to Cloudflare MX or mailflatimo
    const isTargetMatched = mxRecords.some(r => {
      const ex = (r.exchange || '').toLowerCase();
      return ex.includes('cloudflare.net') || ex.includes('mailflatimo') || ex.includes('flatimo');
    });

    if (!isTargetMatched) {
      const currentExchanges = mxRecords.map(r => `${r.exchange} (Priority ${r.priority})`).join(', ');
      return {
        success: false,
        reason: `Record MX saat ini mengarah ke: ${currentExchanges}.`,
        foundRecords: mxRecords
      };
    }

    return {
      success: true,
      records: mxRecords,
      isTargetMatched: true
    };
  } catch (err) {
    let reason = err.message;
    if (err.code === 'ENODATA' || err.code === 'ENOTFOUND') {
      reason = 'Record MX belum terdeteksi di server DNS global. Pastikan Anda sudah menyimpan pengaturan DNS dan menunggu 1-2 menit untuk propagasi.';
    }
    return {
      success: false,
      reason,
      foundRecords: []
    };
  }
}

// Keyboards generator
function getMainMenuKeyboard(isAdmin) {
  if (isAdmin) {
    return {
      inline_keyboard: [
        [
          { text: 'Tambah Domain', callback_data: 'admin_add_domain' },
          { text: 'Hapus Domain', callback_data: 'admin_del_domain' }
        ],
        [
          { text: 'Daftar Domain', callback_data: 'admin_list_domains' },
          { text: 'Statistik Server', callback_data: 'admin_stats' }
        ],
        [
          { text: 'Hubungkan Domain (Alur User)', callback_data: 'user_add_domain' }
        ],
        [
          { text: 'Buka Web Flatimo Mail', url: 'https://mailflatimo.web.id' }
        ]
      ]
    };
  }

  return {
    inline_keyboard: [
      [
        { text: 'Hubungkan Domain Baru', callback_data: 'user_add_domain' }
      ],
      [
        { text: 'Buka Web Flatimo Mail', url: 'https://mailflatimo.web.id' }
      ]
    ]
  };
}

function getDnsGuideKeyboard(domain) {
  return {
    inline_keyboard: [
      [
        { text: 'Saya Sudah Pasang DNS', callback_data: `verify_dns_${domain}` }
      ],
      [
        { text: 'Batal', callback_data: 'cancel_action' }
      ]
    ]
  };
}

function getVerifiedSuccessKeyboard(domain) {
  return {
    inline_keyboard: [
      [
        { text: 'Kirim Test Email Otomatis', callback_data: `auto_test_${domain}` }
      ],
      [
        { text: 'Buka SendTestEmail.com', url: 'https://sendtestemail.com/' },
        { text: 'Buka Inbox di Web', url: `https://mailflatimo.web.id/inbox/test@${domain}` }
      ],
      [
        { text: 'Kembali ke Menu Utama', callback_data: 'cancel_action' }
      ]
    ]
  };
}

function getCancelKeyboard() {
  return {
    inline_keyboard: [
      [{ text: 'Batal', callback_data: 'cancel_action' }]
    ]
  };
}

// Global Event Listener: Real-time notification when ANY email arrives at server
eventBus.on('mail:any', async ({ inbox, message }) => {
  try {
    const domain = inbox.split('@')[1];
    if (!domain) return;

    const targetChatId = domainWatchers.get(domain) || ADMIN_ID;
    if (!targetChatId) return;

    const sender = message.from?.name ? `${message.from.name} <${message.from.address || message.from.text}>` : (message.from?.address || message.from?.text || 'Unknown');
    const otpText = message.otp ? `\n• <b>Kode OTP / Verifikasi:</b> <code>${message.otp}</code>` : '';

    const notifyText = `⚡ <b>EMAIL BARU TELAH DITERIMA (LIVE)</b>\n\n` +
      `• <b>Domain:</b> <code>${domain}</code>\n` +
      `• <b>Kotak Masuk:</b> <code>${inbox}</code>\n` +
      `• <b>Dari:</b> <code>${sender}</code>\n` +
      `• <b>Subjek:</b> <b>${message.subject || '(Tanpa Subjek)'}</b>` +
      otpText + `\n\n` +
      `🔗 <b>Buka Kotak Masuk:</b>\n` +
      `https://mailflatimo.web.id/inbox/${encodeURIComponent(inbox)}`;

    await sendMessage(targetChatId, notifyText);
  } catch (err) {
    console.error('[TelegramBot Event Listener Error]:', err.message);
  }
});

// Handle updates
async function handleUpdate(update) {
  // 1. Handle Callback Query (Inline Button clicks)
  if (update.callback_query) {
    const cb = update.callback_query;
    const chatId = cb.message.chat.id;
    const messageId = cb.message.message_id;
    const data = cb.data;
    const userId = String(cb.from.id);
    const isAdmin = userId === ADMIN_ID;

    await answerCallback(cb.id);

    // Cancel action
    if (data === 'cancel_action') {
      userSessions.delete(chatId);
      const text = isAdmin 
        ? '<b>PANEL UTAMA FLATIMO MAIL</b>\n\nSilakan pilih menu di bawah ini:'
        : '<b>FLATIMO MAIL - SISTEM INTEGRASI DOMAIN</b>\n\nLayanan email sementara mandiri dengan sinkronisasi domain otomatis.';
      return await editMessage(chatId, messageId, text, getMainMenuKeyboard(isAdmin));
    }

    // User: Add domain button
    if (data === 'user_add_domain') {
      userSessions.set(chatId, { state: 'AWAITING_USER_DOMAIN', messageId });
      const text = '<b>HUBUNGKAN DOMAIN BARU</b>\n\nSilakan ketik nama domain Anda yang ingin dihubungkan ke Flatimo Mail.\n\nContoh: <code>domainku.com</code>';
      return await editMessage(chatId, messageId, text, getCancelKeyboard());
    }

    // User: Trigger Auto Test Email
    if (data.startsWith('auto_test_')) {
      const domain = data.replace('auto_test_', '').trim();
      const testEmail = `test@${domain}`;

      await editMessage(chatId, messageId, `<b>SEDANG MENGIRIM EMAIL TEST KE:</b> <code>${testEmail}</code>...`);

      try {
        await fetch(`${API_BASE}/test-email`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-API-Key': API_KEY },
          body: JSON.stringify({
            to: testEmail,
            subject: '⚡ Uji Coba Penerimaan Email Flatimo Mail Berhasil',
            text: `Halo! Ini adalah email pengujian otomatis untuk memverifikasi bahwa domain ${domain} telah 100% siap menerima pesan di Flatimo Mail.`
          })
        });

        const successDispatchText = `<b>EMAIL TEST BERHASIL DIKIRIM & DITERIMA!</b>\n\n` +
          `• <b>Domain:</b> <code>${domain}</code>\n` +
          `• <b>Kotak Masuk:</b> <code>${testEmail}</code>\n` +
          `• <b>Status Ingestion:</b> <b>100% Sukses Real-time</b>\n\n` +
          `Anda juga bisa melakukan pengujian manual dari layanan luar:\n` +
          `👉 https://sendtestemail.com/\n\n` +
          `🔗 <b>Buka Kotak Masuk:</b>\n` +
          `https://mailflatimo.web.id/inbox/${encodeURIComponent(testEmail)}`;

        return await editMessage(chatId, messageId, successDispatchText, getVerifiedSuccessKeyboard(domain));
      } catch (err) {
        return await editMessage(chatId, messageId, `Gagal mengirim email test: ${err.message}`, getVerifiedSuccessKeyboard(domain));
      }
    }

    // User: Verify DNS clicked (Strict real DNS resolution)
    if (data.startsWith('verify_dns_')) {
      const domain = data.replace('verify_dns_', '').trim();
      
      await editMessage(chatId, messageId, `<b>SEDANG MEMVERIFIKASI DNS SECARA REAL-TIME...</b>\n\nMemeriksa catatan MX global untuk domain: <code>${domain}</code>`);

      const verifyResult = await verifyDomainMx(domain);

      if (!verifyResult.success) {
        const text = `<b>VERIFIKASI DNS BELUM BERHASIL</b>\n\n` +
          `Domain: <code>${domain}</code>\n` +
          `Status: <i>${verifyResult.reason}</i>\n\n` +
          `<b>PANDUAN DNS RECORD:</b>\n` +
          `1. Tipe: <code>MX</code> | Host: <code>@</code> | Target: <code>rute1.mx.cloudflare.net</code> | Priority: <code>10</code>\n` +
          `2. Tipe: <code>MX</code> | Host: <code>@</code> | Target: <code>rute2.mx.cloudflare.net</code> | Priority: <code>50</code>\n` +
          `3. Tipe: <code>MX</code> | Host: <code>@</code> | Target: <code>rute3.mx.cloudflare.net</code> | Priority: <code>99</code>\n\n` +
          `<i>(Atau aktifkan Email Routing di Cloudflare lalu arahkan ke Worker Flatimo Mail).</i>\n\n` +
          `Simpan DNS Anda, tunggu 1-2 menit untuk propagasi, lalu klik tombol verifikasi di bawah lagi.`;
        return await editMessage(chatId, messageId, text, getDnsGuideKeyboard(domain));
      }

      // Add domain to Flatimo Mail database
      db.addDomain(domain);
      domainWatchers.set(domain, chatId);

      const testAddress = `test@${domain}`;
      userSessions.delete(chatId);

      const successText = `<b>VERIFIKASI REAL-TIME SUKSES! DOMAIN TELAH AKTIF</b>\n\n` +
        `• <b>Domain:</b> <code>${domain}</code>\n` +
        `• <b>Status DNS:</b> <b>Terverifikasi 100%</b>\n` +
        `• <b>Status Web:</b> <b>Aktif di Dropdown</b>\n\n` +
        `<b>UJI COBA PENERIMAAN EMAIL:</b>\n` +
        `Silakan uji penerimaan email ke: <code>${testAddress}</code>\n\n` +
        `Anda bisa menguji secara instan dengan tombol di bawah, atau kirim email nyata lewat https://sendtestemail.com/\n\n` +
        `<i>Bot ini akan otomatis memberikan notifikasi seketika begitu email uji coba Anda mendarat di server!</i>`;

      return await editMessage(chatId, messageId, successText, getVerifiedSuccessKeyboard(domain));
    }

    // Admin: List domains
    if (data === 'admin_list_domains' && isAdmin) {
      const domains = db.getDomains();
      let text = `<b>DAFTAR DOMAIN AKTIF (${domains.length})</b>\n\n`;
      domains.forEach((d, i) => {
        text += `${i + 1}. <code>${d}</code>\n`;
      });
      text += `\nWebsite: https://mailflatimo.web.id`;

      return await editMessage(chatId, messageId, text, {
        inline_keyboard: [[{ text: 'Kembali', callback_data: 'cancel_action' }]]
      });
    }

    // Admin: Delete domain menu
    if (data === 'admin_del_domain' && isAdmin) {
      const domains = db.getDomains();
      if (domains.length <= 1) {
        return await editMessage(chatId, messageId, '<b>HAPUS DOMAIN</b>\n\nHanya tersisa 1 domain utama. Domain utama tidak dapat dihapus.', {
          inline_keyboard: [[{ text: 'Kembali', callback_data: 'cancel_action' }]]
        });
      }

      const buttons = domains.map(d => [
        { text: `Hapus: ${d}`, callback_data: `confirm_del_${d}` }
      ]);
      buttons.push([{ text: 'Kembali', callback_data: 'cancel_action' }]);

      return await editMessage(chatId, messageId, '<b>PILIH DOMAIN YANG INGIN DIHAPUS:</b>', {
        inline_keyboard: buttons
      });
    }

    // Admin: Confirm delete
    if (data.startsWith('confirm_del_') && isAdmin) {
      const domainToDel = data.replace('confirm_del_', '').trim();
      db.removeDomain(domainToDel);
      domainWatchers.delete(domainToDel);

      return await editMessage(chatId, messageId, `<b>DOMAIN BERHASIL DIHAPUS</b>\n\nDomain <code>${domainToDel}</code> telah dihapus dari sistem Flatimo Mail.`, {
        inline_keyboard: [[{ text: 'Kembali ke Menu', callback_data: 'cancel_action' }]]
      });
    }

    // Admin: Add domain (Instant bypass)
    if (data === 'admin_add_domain' && isAdmin) {
      userSessions.set(chatId, { state: 'AWAITING_ADMIN_DOMAIN', messageId });
      const text = '<b>TAMBAH DOMAIN (ADMIN INSTANT)</b>\n\nKetik nama domain yang ingin langsung didaftarkan ke sistem tanpa menunggu verifikasi DNS:';
      return await editMessage(chatId, messageId, text, getCancelKeyboard());
    }

    // Admin: Server Stats
    if (data === 'admin_stats' && isAdmin) {
      const domains = db.getDomains();
      const inboxes = db.inboxes ? db.inboxes.size : 0;
      const messages = db.messages ? db.messages.size : 0;
      const uptimeSec = Math.floor(process.uptime());
      const hours = Math.floor(uptimeSec / 3600);
      const minutes = Math.floor((uptimeSec % 3600) / 60);

      const text = `<b>STATISTIK SERVER FLATIMO MAIL</b>\n\n` +
        `• Status Server: <b>ONLINE (Active)</b>\n` +
        `• Uptime: <b>${hours} Jam ${minutes} Menit</b>\n` +
        `• Total Domain Aktif: <b>${domains.length}</b>\n` +
        `• Total Inbox Terbuat: <b>${inboxes}</b>\n` +
        `• Total Pesan di Database: <b>${messages}</b>\n` +
        `• Port Backend: <b>${config.port}</b>\n` +
        `• Port SMTP: <b>${config.smtpPort}</b>\n` +
        `• Retensi Email: <b>24 Jam</b>`;

      return await editMessage(chatId, messageId, text, {
        inline_keyboard: [[{ text: 'Kembali', callback_data: 'cancel_action' }]]
      });
    }
  }

  // 2. Handle Text Messages with Auto-Delete & Clean In-Place Edit
  if (update.message && update.message.text) {
    const msg = update.message;
    const chatId = msg.chat.id;
    const text = msg.text.trim();
    const userMsgId = msg.message_id;
    const userId = String(msg.from.id);
    const isAdmin = userId === ADMIN_ID;

    // Automatically delete user typed text message for clean session
    await deleteMessage(chatId, userMsgId);

    const session = userSessions.get(chatId);
    const existingMsgId = session?.messageId;

    // Command /start or /menu
    if (text === '/start' || text === '/menu') {
      const greeting = isAdmin 
        ? '<b>PANEL UTAMA FLATIMO MAIL</b>\n\nSelamat datang di sistem manajemen domain Flatimo Mail. Silakan pilih menu di bawah:'
        : '<b>FLATIMO MAIL - SISTEM INTEGRASI DOMAIN</b>\n\nHubungkan domain Anda sendiri ke Flatimo Mail untuk menerima email sementara secara otomatis.';

      if (existingMsgId) {
        const editRes = await editMessage(chatId, existingMsgId, greeting, getMainMenuKeyboard(isAdmin));
        if (editRes.ok) return;
      }

      const newMsg = await sendMessage(chatId, greeting, getMainMenuKeyboard(isAdmin));
      if (newMsg.ok && newMsg.result) {
        userSessions.set(chatId, { messageId: newMsg.result.message_id });
      }
      return;
    }

    // Process Domain Input from User
    if (session && session.state === 'AWAITING_USER_DOMAIN') {
      const cleanDomain = text.toLowerCase().replace(/^(https?:\/\/)/, '').replace(/\/$/, '').replace(/^@/, '').trim();

      if (!cleanDomain.includes('.') || cleanDomain.length < 3) {
        const errorText = '<b>FORMAT DOMAIN TIDAK VALID</b>\n\nHarap ketik nama domain yang benar (contoh: <code>domainku.com</code>):';
        if (existingMsgId) {
          return await editMessage(chatId, existingMsgId, errorText, getCancelKeyboard());
        }
        const m = await sendMessage(chatId, errorText, getCancelKeyboard());
        if (m.ok && m.result) userSessions.set(chatId, { state: 'AWAITING_USER_DOMAIN', messageId: m.result.message_id });
        return;
      }

      const guideText = `<b>PANDUAN KONEKSI DNS UNTUK:</b> <code>${cleanDomain}</code>\n\n` +
        `Silakan masukkan catatan DNS berikut di panel tempat Anda membeli domain:\n\n` +
        `<b>CATATAN RECORD MX RESMI:</b>\n` +
        `1. Tipe: <code>MX</code> | Host: <code>@</code> | Target: <code>rute1.mx.cloudflare.net</code> | Priority: <code>10</code>\n` +
        `2. Tipe: <code>MX</code> | Host: <code>@</code> | Target: <code>rute2.mx.cloudflare.net</code> | Priority: <code>50</code>\n` +
        `3. Tipe: <code>MX</code> | Host: <code>@</code> | Target: <code>rute3.mx.cloudflare.net</code> | Priority: <code>99</code>\n\n` +
        `<i>(Atau jika domain di Cloudflare: Aktifkan Email Routing lalu arahkan Catch-all ke Worker Flatimo Mail).</i>\n\n` +
        `Setelah menyimpan DNS di atas, klik tombol <b>Saya Sudah Pasang DNS</b> di bawah ini:`;

      if (existingMsgId) {
        return await editMessage(chatId, existingMsgId, guideText, getDnsGuideKeyboard(cleanDomain));
      }
      const m = await sendMessage(chatId, guideText, getDnsGuideKeyboard(cleanDomain));
      if (m.ok && m.result) userSessions.set(chatId, { messageId: m.result.message_id });
      return;
    }

    // Process Domain Input from Admin (Instant Add)
    if (session && session.state === 'AWAITING_ADMIN_DOMAIN' && isAdmin) {
      const cleanDomain = text.toLowerCase().replace(/^(https?:\/\/)/, '').replace(/\/$/, '').replace(/^@/, '').trim();

      if (!cleanDomain.includes('.') || cleanDomain.length < 3) {
        const errorText = '<b>FORMAT DOMAIN TIDAK VALID</b>\n\nHarap ketik nama domain yang benar:';
        if (existingMsgId) {
          return await editMessage(chatId, existingMsgId, errorText, getCancelKeyboard());
        }
        return;
      }

      db.addDomain(cleanDomain);
      domainWatchers.set(cleanDomain, chatId);

      const resText = `<b>DOMAIN BERHASIL DITAMBAHKAN</b>\n\nDomain <code>${cleanDomain}</code> telah didaftarkan ke sistem dan langsung aktif di dropdown website https://mailflatimo.web.id.\n\nAnda bisa mencoba kirim email nyata dari https://sendtestemail.com/ ke <code>test@${cleanDomain}</code>.`;
      
      if (existingMsgId) {
        return await editMessage(chatId, existingMsgId, resText, getMainMenuKeyboard(isAdmin));
      }
      const m = await sendMessage(chatId, resText, getMainMenuKeyboard(isAdmin));
      if (m.ok && m.result) userSessions.set(chatId, { messageId: m.result.message_id });
      return;
    }

    // Default fallback
    const fallbackText = isAdmin 
      ? '<b>PANEL UTAMA FLATIMO MAIL</b>\n\nSilakan pilih menu di bawah:'
      : '<b>FLATIMO MAIL - SISTEM INTEGRASI DOMAIN</b>\n\nHubungkan domain Anda sendiri ke Flatimo Mail.';

    if (existingMsgId) {
      return await editMessage(chatId, existingMsgId, fallbackText, getMainMenuKeyboard(isAdmin));
    }
    const newMsg = await sendMessage(chatId, fallbackText, getMainMenuKeyboard(isAdmin));
    if (newMsg.ok && newMsg.result) {
      userSessions.set(chatId, { messageId: newMsg.result.message_id });
    }
  }
}

// Long Polling Runner
let lastUpdateId = 0;
let isPolling = false;

export function startTelegramBot() {
  if (isPolling) return;
  isPolling = true;

  console.log(`[TelegramBot] Initializing Enhanced Real-time Telegram Bot for Admin ID: ${ADMIN_ID} ...`);

  async function pollLoop() {
    try {
      const res = await fetch(`${TG_API}/getUpdates?offset=${lastUpdateId + 1}&timeout=25`);
      const data = await res.json();

      if (data.ok && Array.isArray(data.result)) {
        for (const update of data.result) {
          lastUpdateId = update.update_id;
          await handleUpdate(update);
        }
      }
    } catch (err) {
      // Network retry backoff
    }

    if (isPolling) {
      setTimeout(pollLoop, 1000);
    }
  }

  pollLoop();
}
