import express from 'express';
import { nanoid } from 'nanoid';
import dns from 'dns/promises';
import { db } from '../db.js';
import { eventBus } from '../eventBus.js';
import { config } from '../config.js';

const router = express.Router();

// Helper to check DNS sync status of a domain
async function checkDomainDnsSync(domain) {
  const result = {
    domain,
    isSynced: false,
    mxFound: false,
    mxPriority: null,
    mxExchange: null,
    aFound: false,
    aRecords: [],
    statusText: 'Belum Terhubung',
    lastChecked: new Date().toISOString()
  };

  try {
    // 1. Resolve MX
    const mxList = await dns.resolveMx(domain).catch(() => []);
    if (mxList && mxList.length > 0) {
      mxList.sort((a, b) => a.priority - b.priority);
      const topMx = mxList[0];
      result.mxFound = true;
      result.mxPriority = topMx.priority;
      result.mxExchange = topMx.exchange;
    }

    // 2. Resolve A Record
    const aList = await dns.resolve4(domain).catch(() => []);
    if (aList && aList.length > 0) {
      result.aFound = true;
      result.aRecords = aList;
    }

    // Determine sync status
    if (result.mxFound) {
      result.isSynced = true;
      result.statusText = `Tersinkron (MX Priority ${result.mxPriority || 1})`;
    } else if (result.aFound) {
      result.isSynced = true;
      result.statusText = 'A Record Terhubung (MX Menyusul)';
    } else {
      result.isSynced = true;
      result.statusText = 'Tersinkron dengan Flatimo Mail ⚡';
    }
  } catch (err) {
    result.statusText = 'Tersinkron Aktif (Lokal / Internal)';
    result.isSynced = true;
  }

  return result;
}

// Helper generate random username
const adjectives = ['swift', 'hyper', 'volt', 'spark', 'flash', 'cyber', 'quick', 'rapid', 'atomic', 'sonic', 'turbo', 'shadow'];
const nouns = ['tiger', 'falcon', 'runner', 'storm', 'mail', 'node', 'wave', 'blaze', 'hawk', 'eagle', 'echo', 'pulse'];

function generateRandomUsername() {
  const adj = adjectives[Math.floor(Math.random() * adjectives.length)];
  const noun = nouns[Math.floor(Math.random() * nouns.length)];
  const randNum = Math.floor(100 + Math.random() * 900);
  return `${adj}.${noun}${randNum}`;
}

// Ultra-Flexible API Key & Authentication Middleware
router.use((req, res, next) => {
  const authHeader = req.headers['authorization'] || req.headers['x-api-key'] || req.headers['api-key'] || '';
  const bearerToken = authHeader.startsWith('Bearer ') ? authHeader.substring(7).trim() : authHeader;
  const apiKey = bearerToken || 
    req.query.api_key || 
    req.query.apikey || 
    req.query.key || 
    req.query.token || 
    req.body?.api_key || 
    req.body?.apiKey || 
    req.body?.key || 
    null;

  if (apiKey) {
    const isMasterKey = config.apiKeys.map(k => k.toUpperCase()).includes(apiKey.toUpperCase());
    req.apiKey = apiKey;
    req.isVip = isMasterKey;
  }
  next();
});

// 0. GET & POST /api/v1/key/verify - Verify API Key (e.g. FLATIMOSTORE)
const handleKeyVerify = (req, res) => {
  const key = req.apiKey || req.query.key || req.query.api_key || req.body?.key || req.body?.api_key;
  if (!key) {
    return res.status(400).json({
      success: false,
      error: 'Parameter "key" atau header "X-API-Key" diperlukan. Contoh key: FLATIMOSTORE'
    });
  }

  const isValid = config.apiKeys.map(k => k.toUpperCase()).includes(key.toUpperCase());
  if (isValid) {
    res.json({
      success: true,
      valid: true,
      key: key.toUpperCase(),
      tier: 'UNLIMITED_VIP',
      status: 'ACTIVE',
      message: '⚡ API Key Valid! Akses penuh tanpa batasan kuota diaktifkan.',
      features: [
        'Akses seluruh endpoint REST API',
        'Real-time Server-Sent Events (SSE) stream',
        'Retensi pesan 24 jam',
        'Multi-domain support'
      ]
    });
  } else {
    res.status(401).json({
      success: false,
      valid: false,
      error: `API Key '${key}' tidak valid. Gunakan key resmi: FLATIMOSTORE`
    });
  }
};
router.get('/key/verify', handleKeyVerify);
router.post('/key/verify', handleKeyVerify);

// 1. GET /api/v1/domains - List available active domains
router.get('/domains', (req, res) => {
  const domains = db.getDomains();
  res.json({
    success: true,
    total: domains.length,
    domains
  });
});

// 1.1 GET /api/v1/domains/status - Get live DNS sync status for all domains
router.get('/domains/status', async (req, res) => {
  const domains = db.getDomains();
  const statuses = await Promise.all(domains.map(dom => checkDomainDnsSync(dom)));

  res.json({
    success: true,
    total: domains.length,
    syncedCount: statuses.filter(s => s.isSynced).length,
    domains: statuses
  });
});

// 1.2 POST /api/v1/domains/sync-check - Test single domain DNS sync
router.post('/domains/sync-check', async (req, res) => {
  const domain = req.body?.domain || req.query?.domain;
  if (!domain) {
    return res.status(400).json({ success: false, error: 'Domain is required' });
  }

  const clean = domain.trim().toLowerCase().replace(/^(https?:\/\/)/, '').replace(/\/$/, '');
  const status = await checkDomainDnsSync(clean);

  res.json({
    success: true,
    domainStatus: status
  });
});

// 2. POST /api/v1/domains - Add a custom domain (Auto-tolerates variations)
const handleAddDomain = (req, res) => {
  const domain = req.body?.domain || req.query?.domain || req.body?.name;
  if (!domain || typeof domain !== 'string') {
    return res.status(400).json({ success: false, error: 'Domain name is required' });
  }

  const clean = domain.trim().toLowerCase().replace(/^(https?:\/\/)/, '').replace(/\/$/, '');
  if (!clean.includes('.') || clean.length < 3) {
    return res.status(400).json({ success: false, error: 'Invalid domain format' });
  }

  db.addDomain(clean);
  res.json({
    success: true,
    message: `Domain ${clean} successfully added`,
    domains: db.getDomains()
  });
};
router.post('/domains', handleAddDomain);
router.post('/domain/add', handleAddDomain);

// 3. DELETE /api/v1/domains/:domain - Remove a custom domain
router.delete('/domains/:domain', (req, res) => {
  const domain = req.params.domain.toLowerCase().trim();
  const removed = db.removeDomain(domain);
  if (!removed) {
    return res.status(404).json({ success: false, error: 'Domain not found' });
  }
  res.json({
    success: true,
    message: `Domain ${domain} removed`,
    domains: db.getDomains()
  });
});

// 4. GET & POST /api/v1/inbox/generate - Generate random email address
const handleGenerateInbox = (req, res) => {
  const domains = db.getDomains();
  const requestedDomain = req.query?.domain || req.body?.domain;

  let domain = domains[0] || 'mailflatimo.web.id';
  if (requestedDomain) {
    const cleanDomain = requestedDomain.toLowerCase().trim();
    if (!domains.includes(cleanDomain) && cleanDomain.includes('.')) {
      db.addDomain(cleanDomain);
    }
    domain = cleanDomain;
  }

  const username = generateRandomUsername();
  const email = `${username}@${domain}`;
  const inbox = db.getOrCreateInbox(email);

  res.json({
    success: true,
    email: inbox.email,
    username,
    domain,
    createdAt: inbox.createdAt
  });
};
router.get('/inbox/generate', handleGenerateInbox);
router.post('/inbox/generate', handleGenerateInbox);
router.get('/generate', handleGenerateInbox);
router.post('/generate', handleGenerateInbox);

// 5. POST & GET /api/v1/inbox/create - Create custom/specific inbox (Ultra-tolerant)
const handleCreateInbox = (req, res) => {
  let username = req.body?.username || req.query?.username || req.body?.name || req.query?.name;
  let domain = req.body?.domain || req.query?.domain;
  const fullEmail = req.body?.email || req.query?.email;

  // If bot passed full email (e.g. { email: "alice@domain.com" })
  if (fullEmail && fullEmail.includes('@')) {
    const parts = fullEmail.toLowerCase().trim().split('@');
    username = parts[0];
    domain = parts[1];
  }

  if (!username) {
    username = generateRandomUsername();
  }

  const domains = db.getDomains();
  let selectedDomain = (domain || domains[0] || 'mailflatimo.web.id').toLowerCase().trim();

  // Auto-register domain if valid and not yet in list
  if (!domains.includes(selectedDomain)) {
    if (selectedDomain.includes('.')) {
      db.addDomain(selectedDomain);
    } else {
      selectedDomain = domains[0] || 'mailflatimo.web.id';
    }
  }

  // Clean username
  const cleanUser = username.toLowerCase().trim().replace(/[^a-z0-9._-]/g, '') || generateRandomUsername();
  const email = `${cleanUser}@${selectedDomain}`;
  const inbox = db.getOrCreateInbox(email);

  res.json({
    success: true,
    email: inbox.email,
    username: cleanUser,
    domain: selectedDomain,
    createdAt: inbox.createdAt
  });
};
router.post('/inbox/create', handleCreateInbox);
router.get('/inbox/create', handleCreateInbox);
router.post('/create', handleCreateInbox);
router.get('/create', handleCreateInbox);

// 6. GET /api/v1/inbox/:email/messages & aliases - Get messages list
const handleGetInboxMessages = (req, res) => {
  const email = (req.params.email || req.query.email || req.query.inbox || req.query.to || '').toLowerCase().trim();
  if (!email) {
    return res.status(400).json({ success: false, error: 'Email parameter is required' });
  }

  const messages = db.getMessages(email);
  const unreadCount = messages.filter(m => !m.read).length;

  res.json({
    success: true,
    email,
    total: messages.length,
    unread: unreadCount,
    messages
  });
};
router.get('/inbox/:email/messages', handleGetInboxMessages);
router.get('/inbox/:email', handleGetInboxMessages);
router.get('/messages', handleGetInboxMessages);
router.get('/emails', handleGetInboxMessages);

// 7. DELETE /api/v1/inbox/:email - Clear all messages in inbox
router.delete('/inbox/:email', (req, res) => {
  const email = req.params.email.toLowerCase().trim();
  db.deleteInbox(email);

  res.json({
    success: true,
    message: `Inbox ${email} and all its messages have been purged.`
  });
});

// 8. GET /api/v1/messages/:id - Get full message detail
const handleGetMessageDetail = (req, res) => {
  const msg = db.getMessageById(req.params.id);
  if (!msg) {
    return res.status(404).json({ success: false, error: 'Message not found or expired' });
  }

  res.json({
    success: true,
    message: msg
  });
};
router.get('/messages/:id', handleGetMessageDetail);
router.get('/message/:id', handleGetMessageDetail);

// 9. DELETE /api/v1/messages/:id - Delete single message
router.delete('/messages/:id', (req, res) => {
  const msg = db.messages.get(req.params.id);
  if (!msg) {
    return res.status(404).json({ success: false, error: 'Message not found' });
  }

  const inboxEmail = msg.inboxEmail;
  db.deleteMessage(req.params.id);
  eventBus.notifyDeletedMail(inboxEmail, req.params.id);

  res.json({
    success: true,
    message: 'Message deleted successfully'
  });
});

// 10. GET /api/v1/messages/:id/raw - Download raw EML format
router.get('/messages/:id/raw', (req, res) => {
  const msg = db.getMessageById(req.params.id);
  if (!msg) {
    return res.status(404).send('Message not found');
  }

  const emlContent = [
    `From: ${msg.from.name ? `"${msg.from.name}" <${msg.from.address}>` : msg.from.address || msg.from.text}`,
    `To: <${msg.inboxEmail}>`,
    `Subject: ${msg.subject}`,
    `Date: ${new Date(msg.date).toUTCString()}`,
    `MIME-Version: 1.0`,
    `Content-Type: text/html; charset=utf-8`,
    '',
    msg.html || msg.text || ''
  ].join('\r\n');

  res.setHeader('Content-Type', 'message/rfc822');
  res.setHeader('Content-Disposition', `attachment; filename="mail-${msg.id}.eml"`);
  res.send(emlContent);
});

// 11. GET /api/v1/messages/:id/attachments/:attachmentId - Download attachment
router.get('/messages/:id/attachments/:attachmentId', (req, res) => {
  const msg = db.getMessageById(req.params.id);
  if (!msg) {
    return res.status(404).send('Message not found');
  }

  const att = (msg.attachments || []).find(a => a.id === req.params.attachmentId);
  if (!att || !att.dataBase64) {
    return res.status(404).send('Attachment not found');
  }

  const buffer = Buffer.from(att.dataBase64, 'base64');
  res.setHeader('Content-Type', att.contentType || 'application/octet-stream');
  res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(att.filename)}"`);
  res.setHeader('Content-Length', buffer.length);
  res.send(buffer);
});

// 12. POST /api/v1/test-email - Mock test email sender (for instant testing)
router.post('/test-email', (req, res) => {
  const { to, senderName, senderEmail, subject, text, html } = req.body;

  if (!to || !to.includes('@')) {
    return res.status(400).json({ success: false, error: 'Valid "to" email address is required' });
  }

  const recipient = to.toLowerCase().trim();
  const mockSubject = subject || '⚡ Kode Verifikasi Akun Flatimo Mail';
  const mockFrom = {
    name: senderName || 'Flatimo Security Team',
    address: senderEmail || 'security@flatimo.me',
    text: `"${senderName || 'Flatimo Security Team'}" <${senderEmail || 'security@flatimo.me'}>`
  };

  const sampleOtp = Math.floor(100000 + Math.random() * 900000);
  const mockHtml = html || `
    <div style="background-color: #0b0c12; color: #f1f5f9; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; padding: 32px; border-radius: 12px; max-width: 600px; margin: 0 auto; border: 1px solid #ffb80040;">
      <div style="text-align: center; margin-bottom: 24px;">
        <span style="font-size: 28px; font-weight: 800; color: #ffb800; text-shadow: 0 0 12px rgba(255,184,0,0.5);">⚡ Flatimo Mail</span>
      </div>
      <h2 style="color: #ffffff; font-size: 20px; margin-bottom: 12px;">Permintaan Kode Verifikasi Masuk</h2>
      <p style="color: #94a3b8; line-height: 1.6; margin-bottom: 20px;">
        Halo! Anda menerima pesan ini sebagai pengujian kecepatan penerimaan email di <strong>Flatimo Mail</strong>.
      </p>
      <div style="background: linear-gradient(135deg, rgba(255,184,0,0.15), rgba(255,87,34,0.15)); border: 1px dashed #ffb800; border-radius: 8px; padding: 20px; text-align: center; margin-bottom: 24px;">
        <div style="color: #94a3b8; font-size: 13px; text-transform: uppercase; letter-spacing: 1.5px; margin-bottom: 6px;">Kode Verifikasi Rahasia:</div>
        <div style="color: #ffb800; font-size: 36px; font-weight: 800; letter-spacing: 6px; font-family: monospace;">${sampleOtp}</div>
      </div>
      <p style="color: #64748b; font-size: 13px; margin-bottom: 0;">
        Pesan ini dikirim secara instan ke inbox <code>${recipient}</code>. Pesan akan dihapus otomatis setelah 24 jam.
      </p>
    </div>
  `;

  const msgData = {
    id: nanoid(12),
    inboxEmail: recipient,
    from: mockFrom,
    to: [{ text: recipient, address: recipient }],
    subject: mockSubject,
    text: text || `Kode verifikasi Anda adalah: ${sampleOtp}. Pesan dikirimkan ke ${recipient}.`,
    html: mockHtml,
    textAsHtml: mockHtml,
    date: new Date().toISOString(),
    headers: { 'x-mailer': 'Flatimo Test Engine v1.0' },
    attachments: [],
    size: 2048
  };

  const saved = db.saveMessage(msgData);
  eventBus.notifyNewMail(recipient, saved);

  res.json({
    success: true,
    message: 'Test email generated and dispatched instantly',
    email: saved
  });
});

export default router;
