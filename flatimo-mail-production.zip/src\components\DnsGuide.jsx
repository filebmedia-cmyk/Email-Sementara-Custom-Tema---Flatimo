import React, { useState } from 'react';
import { Check, Copy, Zap, Server, ShieldCheck } from 'lucide-react';

export default function DnsGuide() {
  const [copiedKey, setCopiedKey] = useState(null);

  const dnsRecords = [
    {
      key: 'mx',
      type: 'MX',
      name: '@',
      target: 'mailflatimo.web.id',
      priority: '1',
      ttl: 'Auto / 3600'
    }
  ];

  const handleCopy = (text, key) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="w-full max-w-4xl mx-auto mt-4 sm:mt-6 px-1 sm:px-0 animate-in fade-in duration-300">
      
      {/* DNS MX Container */}
      <div className="rounded-2xl sm:rounded-3xl bg-dark-900/95 border border-brand-yellow/30 shadow-glow-yellow-sm p-4 sm:p-7 md:p-8 backdrop-blur-xl">
        
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5 sm:mb-6 pb-4 sm:pb-5 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2 sm:p-2.5 rounded-xl sm:rounded-2xl bg-brand-yellow/15 text-brand-yellow border border-brand-yellow/30 shrink-0">
              <Zap className="w-5 h-5 sm:w-6 sm:h-6 fill-brand-yellow" />
            </div>
            <div>
              <h1 className="text-lg sm:text-2xl font-black text-white">
                Pengaturan DNS MX Record
              </h1>
              <p className="text-xs text-slate-400 mt-0.5">
                Cukup tambahkan 1 baris record MX ini di domain baru mana saja yang Anda beli:
              </p>
            </div>
          </div>

          <span className="text-[11px] sm:text-xs font-bold text-emerald-400 bg-emerald-500/10 px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-xl border border-emerald-500/30 self-start sm:self-auto shrink-0">
            ⚡ MX Priority 1 (Instant Sync)
          </span>
        </div>

        {/* --- MOBILE DISPLAY (Responsive Card Stack) --- */}
        <div className="block sm:hidden space-y-3">
          {dnsRecords.map((rec) => (
            <div 
              key={rec.key}
              className="p-4 rounded-xl bg-dark-950 border border-slate-800 space-y-3 font-mono text-xs"
            >
              {/* Row 1: Tipe & Priority */}
              <div className="flex items-center justify-between">
                <span className="font-bold px-2.5 py-1 rounded-lg text-xs bg-brand-orange/20 text-brand-orange border border-brand-orange/40 shadow-glow-orange-sm">
                  Tipe: {rec.type}
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-brand-yellow/15 border border-brand-yellow/30 text-brand-yellow font-bold text-xs">
                  Priority: 1 ⚡
                </span>
              </div>

              {/* Row 2: Host / Nama */}
              <div className="flex items-center justify-between pt-1 border-t border-slate-900">
                <span className="text-slate-400 font-sans text-xs">Host / Nama:</span>
                <span className="text-white font-bold text-sm bg-dark-900 px-2.5 py-0.5 rounded border border-slate-800">
                  {rec.name}
                </span>
              </div>

              {/* Row 3: Target Value */}
              <div className="pt-1 border-t border-slate-900">
                <span className="text-slate-400 font-sans text-xs block mb-1">Target / Nilai (Value):</span>
                <div className="text-brand-yellow font-bold text-sm break-all bg-dark-900 p-2.5 rounded-lg border border-brand-yellow/25 select-all">
                  {rec.target}
                </div>
              </div>

              {/* Row 4: TTL */}
              <div className="flex items-center justify-between pt-1 border-t border-slate-900 text-[11px] text-slate-400">
                <span className="font-sans">TTL:</span>
                <span>{rec.ttl}</span>
              </div>

              {/* Copy Button (Full Width Mobile) */}
              <button
                onClick={() => handleCopy(rec.target, rec.key)}
                className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-gradient-to-r from-brand-yellow to-brand-orange text-dark-950 font-bold text-xs shadow-glow-yellow-sm active:scale-95 transition-all mt-2"
              >
                {copiedKey === rec.key ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{copiedKey === rec.key ? 'Target MX Disalin!' : 'Salin Target (mailflatimo.web.id)'}</span>
              </button>
            </div>
          ))}
        </div>

        {/* --- DESKTOP & TABLET DISPLAY (Horizontal Table) --- */}
        <div className="hidden sm:block overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-bold">
                <th className="pb-3 px-3">Tipe</th>
                <th className="pb-3 px-3">Host / Nama</th>
                <th className="pb-3 px-3">Target (Value)</th>
                <th className="pb-3 px-3">Priority</th>
                <th className="pb-3 px-3">TTL</th>
                <th className="pb-3 px-3 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {dnsRecords.map((rec) => (
                <tr key={rec.key} className="hover:bg-dark-850/60 transition-colors">
                  <td className="py-4 px-3">
                    <span className="font-bold px-2.5 py-1 rounded-lg text-xs bg-brand-orange/20 text-brand-orange border border-brand-orange/40 shadow-glow-orange-sm">
                      {rec.type}
                    </span>
                  </td>
                  <td className="py-4 px-3 text-white font-bold text-sm">{rec.name}</td>
                  <td className="py-4 px-3 text-brand-yellow font-bold text-sm">{rec.target}</td>
                  <td className="py-4 px-3 font-bold text-brand-yellow text-sm">
                    <span className="px-2.5 py-0.5 rounded-md bg-brand-yellow/15 border border-brand-yellow/30">
                      1 ⚡
                    </span>
                  </td>
                  <td className="py-4 px-3 text-slate-400 text-xs">{rec.ttl}</td>
                  <td className="py-4 px-3 text-right">
                    <button
                      onClick={() => handleCopy(rec.target, rec.key)}
                      title="Salin Target MX"
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-dark-950 border border-slate-700 hover:border-brand-yellow text-slate-300 hover:text-brand-yellow text-xs font-semibold ml-auto transition-all active:scale-95"
                    >
                      {copiedKey === rec.key ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedKey === rec.key ? 'Disalin!' : 'Salin'}</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Footer Note */}
        <div className="mt-5 sm:mt-6 pt-4 border-t border-slate-800 text-xs text-slate-400 flex items-center gap-2">
          <Server className="w-4 h-4 text-brand-yellow shrink-0" />
          <span>
            Setiap domain baru yang mengarahkan MX ke <code className="text-brand-yellow font-bold">mailflatimo.web.id</code> akan otomatis diterima dan disinkronkan ke web Flatimo Mail.
          </span>
        </div>

      </div>

    </div>
  );
}
