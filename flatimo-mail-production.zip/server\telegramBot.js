import dns from 'dns/promises';
import { db } from './db.js';
import { config } from './config.js';

const BOT_TOKEN = '8930418014:AAH36qodGrL87Q3i6WukUBayuoGSKRaEvyY';
const ADMIN_ID = '6286514348';
const API_BASE = `http://127.0.0.1:${config.port || 3000}/api/v1`;
const API_KEY = 'FLATIMOSTORE';
const TG_API = `https://api.telegram.org/bot${BOT_TOKEN}`;

// State storage per user
const userSessions = new Map();

// Helper Telegram API calls
async function callTelegram(method, body) {
  try {
    const res = await fetch(`${TG_API}/${method}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    return await res.json();
  } catch (err) {
    console.error(`[TelegramBot Error] ${method}:`, err.message);
    return { ok: false, error: err.message };
  }
}

async function sendMessage(chatId, text, replyMarkup = null) {
  return await callTelegram('sendMessage', {
    chat_id: chatId,
    text,
    parse_mode: 'HTML',
    reply_markup: replyMarkup,
    disable_web_page_preview: true
  });
}

async function editMessage(chatId, messageId, text, replyMarkup = null) {
  return await callTelegram('editMessageText', {
    chat_id: chatId,
    message_id: messageId,
    text,
    parse_mode: 'HTML',
    reply_markup: replyMarkup,
    disable_web_page_preview: true
  });
}

async function answerCallback(callbackQueryId, text = null) {
  return await callTelegram('answerCallbackQuery', {
    callback_query_id: callbackQueryId,
    text: text || undefined
  });
}

// DNS Checker helper
async function verifyDomainMx(domain) {
  try {
    const mxRecords = await dns.resolveMx(domain);
    if (!mxRecords || mxRecords.length === 0) {
      return { success: false, reason: 'Record MX tidak ditemukan pada domain ini.' };
    }

    // Check if points to mailflatimo or cloudflare
    const validTarget = mxRecords.some(r => {
      const ex = (r.exchange || '').toLowerCase();
      return ex.includes('mailflatimo') || ex.includes('cloudflare.net') || ex.includes('flatimo');
    });

    return {
      success: true,
      records: mxRecords,
      isTargetMatched: validTarget
    };
  } catch (err) {
    return {
      success: false,
      reason: err.code === 'ENODATA' || err.code === 'ENOTFOUND' 
        ? 'Record MX belum terdeteksi. DNS mungkin masih dalam proses propagasi.' 
        : err.message
    };
  }
}

// Keyboards generator
function getMainMenuKeyboard(isAdmin) {
  if (isAdmin) {
    return {
      inline_keyboard: [
        [
          { text: 'Tambah Domain', callback_data: 'admin_add_domain' },
          { text: 'Hapus Domain', callback_data: 'admin_del_domain' }
        ],
        [
          { text: 'Daftar Domain', callback_data: 'admin_list_domains' },
          { text: 'Statistik Server', callback_data: 'admin_stats' }
        ],
        [
          { text: 'Hubungkan Domain (Alur User)', callback_data: 'user_add_domain' }
        ],
        [
          { text: 'Buka Web Flatimo Mail', url: 'https://mailflatimo.web.id' }
        ]
      ]
    };
  }

  return {
    inline_keyboard: [
      [
        { text: 'Hubungkan Domain Baru', callback_data: 'user_add_domain' }
      ],
      [
        { text: 'Buka Web Flatimo Mail', url: 'https://mailflatimo.web.id' }
      ]
    ]
  };
}

function getDnsGuideKeyboard(domain) {
  return {
    inline_keyboard: [
      [
        { text: 'Saya Sudah Pasang DNS', callback_data: `verify_dns_${domain}` }
      ],
      [
        { text: 'Batal', callback_data: 'cancel_action' }
      ]
    ]
  };
}

function getCancelKeyboard() {
  return {
    inline_keyboard: [
      [{ text: 'Batal', callback_data: 'cancel_action' }]
    ]
  };
}

// Handle updates
async function handleUpdate(update) {
  // 1. Handle Callback Query (Inline Button clicks)
  if (update.callback_query) {
    const cb = update.callback_query;
    const chatId = cb.message.chat.id;
    const messageId = cb.message.message_id;
    const data = cb.data;
    const userId = String(cb.from.id);
    const isAdmin = userId === ADMIN_ID;

    await answerCallback(cb.id);

    // Cancel action
    if (data === 'cancel_action') {
      userSessions.delete(chatId);
      const text = isAdmin 
        ? '<b>PANEL UTAMA FLATIMO MAIL</b>\n\nSilakan pilih menu di bawah ini:'
        : '<b>FLATIMO MAIL - SISTEM INTEGRASI DOMAIN</b>\n\nLayanan email sementara mandiri dengan sinkronisasi domain otomatis.';
      return await editMessage(chatId, messageId, text, getMainMenuKeyboard(isAdmin));
    }

    // User: Add domain button
    if (data === 'user_add_domain') {
      userSessions.set(chatId, { state: 'AWAITING_USER_DOMAIN', messageId });
      const text = '<b>HUBUNGKAN DOMAIN BARU</b>\n\nSilakan ketik nama domain Anda yang ingin dihubungkan ke Flatimo Mail.\n\nContoh: <code>domainku.com</code>';
      return await editMessage(chatId, messageId, text, getCancelKeyboard());
    }

    // User: Verify DNS clicked
    if (data.startsWith('verify_dns_')) {
      const domain = data.replace('verify_dns_', '').trim();
      
      await editMessage(chatId, messageId, `<b>SEDANG MEMVERIFIKASI DNS...</b>\n\nMemeriksa catatan MX untuk domain: <code>${domain}</code>`);

      const verifyResult = await verifyDomainMx(domain);

      if (!verifyResult.success) {
        const text = `<b>VERIFIKASI DNS BELUM BERHASIL</b>\n\n` +
          `Domain: <code>${domain}</code>\n` +
          `Status: <i>${verifyResult.reason}</i>\n\n` +
          `<b>PANDUAN DNS:</b>\n` +
          `• Tipe: <code>MX</code>\n` +
          `• Nama/Host: <code>@</code>\n` +
          `• Target: <code>mailflatimo.web.id</code>\n` +
          `• Priority: <code>1</code>\n\n` +
          `Jika baru saja memasang DNS, tunggu 1-2 menit untuk proses propagasi global.`;
        return await editMessage(chatId, messageId, text, getDnsGuideKeyboard(domain));
      }

      // Add domain to Flatimo Mail database
      db.addDomain(domain);

      // Perform automated live verification test email
      try {
        await fetch(`${API_BASE}/test-email`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-API-Key': API_KEY },
          body: JSON.stringify({
            to: `test@${domain}`,
            subject: 'Uji Coba Sinkronisasi Domain Flatimo Mail Sukses',
            text: `Domain ${domain} berhasil diverifikasi dan tersambung penuh dengan Flatimo Mail.`
          })
        });
      } catch (e) {}

      userSessions.delete(chatId);

      const successText = `<b>VERIFIKASI SUKSES! DOMAIN TELAH AKTIF</b>\n\n` +
        `Domain: <code>${domain}</code>\n` +
        `Status: <b>Tersinkronisasi 100%</b>\n` +
        `Uji Ingestion: <b>Berhasil Terkirim</b>\n\n` +
        `Domain ini sudah otomatis muncul di menu dropdown website dan siap digunakan:\n` +
        `https://mailflatimo.web.id`;

      return await editMessage(chatId, messageId, successText, getMainMenuKeyboard(isAdmin));
    }

    // Admin: List domains
    if (data === 'admin_list_domains' && isAdmin) {
      const domains = db.getDomains();
      let text = `<b>DAFTAR DOMAIN AKTIF (${domains.length})</b>\n\n`;
      domains.forEach((d, i) => {
        text += `${i + 1}. <code>${d}</code>\n`;
      });
      text += `\nWebsite: https://mailflatimo.web.id`;

      return await editMessage(chatId, messageId, text, {
        inline_keyboard: [[{ text: 'Kembali', callback_data: 'cancel_action' }]]
      });
    }

    // Admin: Delete domain menu
    if (data === 'admin_del_domain' && isAdmin) {
      const domains = db.getDomains();
      if (domains.length <= 1) {
        return await editMessage(chatId, messageId, '<b>HAPUS DOMAIN</b>\n\nHanya tersisa 1 domain utama. Domain utama tidak dapat dihapus.', {
          inline_keyboard: [[{ text: 'Kembali', callback_data: 'cancel_action' }]]
        });
      }

      const buttons = domains.map(d => [
        { text: `Hapus: ${d}`, callback_data: `confirm_del_${d}` }
      ]);
      buttons.push([{ text: 'Kembali', callback_data: 'cancel_action' }]);

      return await editMessage(chatId, messageId, '<b>PILIH DOMAIN YANG INGIN DIHAPUS:</b>', {
        inline_keyboard: buttons
      });
    }

    // Admin: Confirm delete
    if (data.startsWith('confirm_del_') && isAdmin) {
      const domainToDel = data.replace('confirm_del_', '').trim();
      db.removeDomain(domainToDel);

      return await editMessage(chatId, messageId, `<b>DOMAIN BERHASIL DIHAPUS</b>\n\nDomain <code>${domainToDel}</code> telah dihapus dari sistem Flatimo Mail.`, {
        inline_keyboard: [[{ text: 'Kembali ke Menu', callback_data: 'cancel_action' }]]
      });
    }

    // Admin: Add domain (Instant bypass)
    if (data === 'admin_add_domain' && isAdmin) {
      userSessions.set(chatId, { state: 'AWAITING_ADMIN_DOMAIN', messageId });
      const text = '<b>TAMBAH DOMAIN (ADMIN INSTANT)</b>\n\nKetik nama domain yang ingin langsung didaftarkan ke sistem tanpa menunggu verifikasi DNS:';
      return await editMessage(chatId, messageId, text, getCancelKeyboard());
    }

    // Admin: Server Stats
    if (data === 'admin_stats' && isAdmin) {
      const domains = db.getDomains();
      const inboxes = db.inboxes ? db.inboxes.size : 0;
      const messages = db.messages ? db.messages.size : 0;
      const uptimeSec = Math.floor(process.uptime());
      const hours = Math.floor(uptimeSec / 3600);
      const minutes = Math.floor((uptimeSec % 3600) / 60);

      const text = `<b>STATISTIK SERVER FLATIMO MAIL</b>\n\n` +
        `• Status Server: <b>ONLINE (Active)</b>\n` +
        `• Uptime: <b>${hours} Jam ${minutes} Menit</b>\n` +
        `• Total Domain Aktif: <b>${domains.length}</b>\n` +
        `• Total Inbox Terbuat: <b>${inboxes}</b>\n` +
        `• Total Pesan di Database: <b>${messages}</b>\n` +
        `• Port Backend: <b>${config.port}</b>\n` +
        `• Port SMTP: <b>${config.smtpPort}</b>\n` +
        `• Retensi Email: <b>24 Jam</b>`;

      return await editMessage(chatId, messageId, text, {
        inline_keyboard: [[{ text: 'Kembali', callback_data: 'cancel_action' }]]
      });
    }
  }

  // 2. Handle Text Messages
  if (update.message && update.message.text) {
    const msg = update.message;
    const chatId = msg.chat.id;
    const text = msg.text.trim();
    const userId = String(msg.from.id);
    const isAdmin = userId === ADMIN_ID;

    const session = userSessions.get(chatId);

    // Command /start
    if (text === '/start' || text === '/menu') {
      userSessions.delete(chatId);
      const greeting = isAdmin 
        ? '<b>PANEL UTAMA FLATIMO MAIL</b>\n\nSelamat datang di sistem manajemen domain Flatimo Mail. Silakan pilih menu di bawah:'
        : '<b>FLATIMO MAIL - SISTEM INTEGRASI DOMAIN</b>\n\nHubungkan domain Anda sendiri ke Flatimo Mail untuk menerima email sementara secara otomatis.';
      return await sendMessage(chatId, greeting, getMainMenuKeyboard(isAdmin));
    }

    // Process Domain Input from User
    if (session && session.state === 'AWAITING_USER_DOMAIN') {
      const cleanDomain = text.toLowerCase().replace(/^(https?:\/\/)/, '').replace(/\/$/, '').replace(/^@/, '').trim();

      if (!cleanDomain.includes('.') || cleanDomain.length < 3) {
        return await sendMessage(chatId, '<b>FORMAT DOMAIN TIDAK VALID</b>\n\nHarap masukkan nama domain yang benar (contoh: <code>domainku.com</code>):', getCancelKeyboard());
      }

      userSessions.delete(chatId);

      const guideText = `<b>PANDUAN KONEKSI DNS UNTUK:</b> <code>${cleanDomain}</code>\n\n` +
        `Silakan buka panel DNS tempat Anda membeli domain, lalu tambahkan 1 baris record berikut:\n\n` +
        `<b>CATATAN RECORD DNS:</b>\n` +
        `• Tipe: <code>MX</code>\n` +
        `• Nama / Host: <code>@</code>\n` +
        `• Target Server: <code>mailflatimo.web.id</code>\n` +
        `• Priority: <code>1</code>\n\n` +
        `Setelah Anda menyimpan record DNS di atas, klik tombol <b>Saya Sudah Pasang DNS</b> di bawah ini untuk memverifikasi secara langsung.`;

      return await sendMessage(chatId, guideText, getDnsGuideKeyboard(cleanDomain));
    }

    // Process Domain Input from Admin (Instant Add)
    if (session && session.state === 'AWAITING_ADMIN_DOMAIN' && isAdmin) {
      const cleanDomain = text.toLowerCase().replace(/^(https?:\/\/)/, '').replace(/\/$/, '').replace(/^@/, '').trim();

      if (!cleanDomain.includes('.') || cleanDomain.length < 3) {
        return await sendMessage(chatId, '<b>FORMAT DOMAIN TIDAK VALID</b>\n\nHarap masukkan domain yang benar:', getCancelKeyboard());
      }

      userSessions.delete(chatId);
      db.addDomain(cleanDomain);

      const resText = `<b>DOMAIN BERHASIL DITAMBAHKAN</b>\n\nDomain <code>${cleanDomain}</code> telah didaftarkan ke sistem dan langsung aktif di dropdown website https://mailflatimo.web.id.`;
      return await sendMessage(chatId, resText, getMainMenuKeyboard(isAdmin));
    }

    // Default fallback
    return await sendMessage(chatId, 'Ketik <code>/start</code> untuk membuka menu Flatimo Mail.');
  }
}

// Long Polling Runner
let lastUpdateId = 0;
let isPolling = false;

export function startTelegramBot() {
  if (isPolling) return;
  isPolling = true;

  console.log(`[TelegramBot] Initializing Real-time Telegram Bot for Admin ID: ${ADMIN_ID} ...`);

  async function pollLoop() {
    try {
      const res = await fetch(`${TG_API}/getUpdates?offset=${lastUpdateId + 1}&timeout=25`);
      const data = await res.json();

      if (data.ok && Array.isArray(data.result)) {
        for (const update of data.result) {
          lastUpdateId = update.update_id;
          await handleUpdate(update);
        }
      }
    } catch (err) {
      // Network retry backoff
    }

    if (isPolling) {
      setTimeout(pollLoop, 1000);
    }
  }

  pollLoop();
}
